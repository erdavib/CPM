package uo.cpm.p3.ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPasswordField;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import java.awt.Toolkit;

public class VentanaRegistro extends JDialog {
	
	private static final long serialVersionUID = 1L;
	private JPanel pnPrincipal;
	private JPanel pnCliente;
	private JLabel lbNombre;
	private JTextField txNombre;
	private JLabel lbAnoNacimiento;
	private JLabel lbContrasena;
	private JLabel lbContrasena2;
	private JPasswordField pw1;
	private JPasswordField pw2;
	private JPanel pnPedido;
	private JButton btCancelar;
	private JButton btAceptar;
	private JRadioButton rbbtLocal;
	private JRadioButton rdbtLlevar;
	private final ButtonGroup bgPedido = new ButtonGroup();
	private JComboBox<String> cbAnos;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaRegistro frame = new VentanaRegistro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaRegistro() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaRegistro.class.getResource("/img/logo.png")));
		setTitle("McDonalds: Datos del Registro");
		setBackground(new Color(255, 255, 255));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 600, 300);
		pnPrincipal = new JPanel();
		pnPrincipal.setBackground(new Color(255, 255, 255));
		pnPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(pnPrincipal);
		pnPrincipal.setLayout(null);
		pnPrincipal.add(getPnCliente());
		pnPrincipal.add(getPnPedido());
		pnPrincipal.add(getBtCancelar());
		pnPrincipal.add(getBtAceptar());
		setLocationRelativeTo(null);
	}
	private JPanel getPnCliente() {
		if (pnCliente == null) {
			pnCliente = new JPanel();
			pnCliente.setBackground(new Color(255, 255, 255));
			pnCliente.setBorder(new TitledBorder(null, "Cliente", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			pnCliente.setBounds(10, 11, 564, 138);
			pnCliente.setLayout(null);
			pnCliente.add(getLbNombre());
			pnCliente.add(getTxNombre());
			pnCliente.add(getLbAnoNacimiento());
			pnCliente.add(getLbContrasena());
			pnCliente.add(getLbContrasena2());
			pnCliente.add(getPw1());
			pnCliente.add(getPw2());
			pnCliente.add(getCbAnos());
		}
		return pnCliente;
	}
	private JLabel getLbNombre() {
		if (lbNombre == null) {
			lbNombre = new JLabel("Nombre y Apellidos");
			lbNombre.setBounds(20, 28, 190, 14);
		}
		return lbNombre;
	}
	private JTextField getTxNombre() {
		if (txNombre == null) {
			txNombre = new JTextField();
			txNombre.setBounds(220, 25, 306, 20);
			txNombre.setColumns(10);
		}
		return txNombre;
	}
	private JLabel getLbAnoNacimiento() {
		if (lbAnoNacimiento == null) {
			lbAnoNacimiento = new JLabel("Ano de nacimiento");
			lbAnoNacimiento.setBounds(20, 53, 190, 14);
		}
		return lbAnoNacimiento;
	}
	private JLabel getLbContrasena() {
		if (lbContrasena == null) {
			lbContrasena = new JLabel("Contrasena");
			lbContrasena.setBounds(20, 78, 190, 14);
		}
		return lbContrasena;
	}
	private JLabel getLbContrasena2() {
		if (lbContrasena2 == null) {
			lbContrasena2 = new JLabel("Reintroduzca contrasena");
			lbContrasena2.setBounds(20, 103, 190, 14);
		}
		return lbContrasena2;
	}
	private JPasswordField getPw1() {
		if (pw1 == null) {
			pw1 = new JPasswordField();
			pw1.setBounds(220, 75, 306, 20);
		}
		return pw1;
	}
	private JPasswordField getPw2() {
		if (pw2 == null) {
			pw2 = new JPasswordField();
			pw2.setBounds(220, 100, 306, 20);
		}
		return pw2;
	}
	private JPanel getPnPedido() {
		if (pnPedido == null) {
			pnPedido = new JPanel();
			pnPedido.setBorder(new TitledBorder(null, "Pedido", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			pnPedido.setBackground(new Color(255, 255, 255));
			pnPedido.setBounds(10, 160, 270, 90);
			pnPedido.setLayout(null);
			pnPedido.add(getRbbtLocal());
			pnPedido.add(getRdbtLlevar());
		}
		return pnPedido;
	}
	private JButton getBtCancelar() {
		if (btCancelar == null) {
			btCancelar = new JButton("Cancelar");
			btCancelar.setMnemonic('C');
			btCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			btCancelar.setBackground(new Color(255, 0, 0));
			btCancelar.setBounds(485, 227, 89, 23);
		}
		return btCancelar;
	}
	private JButton getBtAceptar() {
		if (btAceptar == null) {
			btAceptar = new JButton("Siguiente");
			btAceptar.setMnemonic('S');
			btAceptar.setForeground(new Color(0, 0, 0));
			btAceptar.setBackground(new Color(0, 255, 0));
			btAceptar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					validarFormulario();
				}
			});
			btAceptar.setBounds(386, 227, 89, 23);
		}
		return btAceptar;
	}
	private boolean validarFormulario() {
		if(isVacioNombre()) {
			JOptionPane.showMessageDialog(this, "Debe introducir un valor para el nombre");
		}
		if(isVacioContrase�a() || isVacioRepetirContrase�a()) {
			JOptionPane.showMessageDialog(this, "Debe introducir un valor para ambas contrase�as");
		}
		if(isIncorrecta(pw1, pw2)) {
			JOptionPane.showMessageDialog(this, "Las contrase�as no coinciden");
		}
		return true;
	}
	private boolean isVacioNombre() {
		return getTxNombre().getText().isBlank();
	}
	private boolean isVacioContrase�a() {
		return pw1.getPassword().toString().isBlank();
	}
	private boolean isVacioRepetirContrase�a() {
		return pw2.getPassword().toString().isBlank();
	}
	private boolean isIncorrecta(JPasswordField c1, JPasswordField c2) {
		return (c1.getPassword().equals(c2.getPassword()));
	}

	private JRadioButton getRbbtLocal() {
		if (rbbtLocal == null) {
			rbbtLocal = new JRadioButton("Local");
			bgPedido.add(rbbtLocal);
			rbbtLocal.setSelected(true);
			rbbtLocal.setBackground(new Color(255, 255, 255));
			rbbtLocal.setBounds(18, 38, 109, 23);
		}
		return rbbtLocal;
	}
	private JRadioButton getRdbtLlevar() {
		if (rdbtLlevar == null) {
			rdbtLlevar = new JRadioButton("Llevar");
			bgPedido.add(rdbtLlevar);
			rdbtLlevar.setBackground(new Color(255, 255, 255));
			rdbtLlevar.setBounds(129, 38, 118, 23);
		}
		return rdbtLlevar;
	}
	private JComboBox<String> getCbAnos() {
		if (cbAnos == null) {
			cbAnos = new JComboBox<String>();
			cbAnos.setModel(new DefaultComboBoxModel<String>(getListaAnios()));
			cbAnos.setBounds(220, 49, 117, 22);
		}
		return cbAnos;
	}
	private String[] getListaAnios() {
		String[] lista = new String[60];
		for(int i=0;i<60;i++) {
			lista[i]= Integer.valueOf(1990+i).toString();
		}
		return lista;
	}
}
