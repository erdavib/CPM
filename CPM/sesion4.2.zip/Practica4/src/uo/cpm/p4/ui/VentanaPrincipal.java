package uo.cpm.p4.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;

import uo.cpm.p3.util.check.ArgumentChecks;
import uo.cpm.p4.exceptions.ItemNotFoundException;
import uo.cpm.p4.model.Articulo;
import uo.cpm.p4.service.McDonalds;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JToggleButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;

public class VentanaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private McDonalds macdonalds;
	private JPanel contentPane;
	private JComboBox<Articulo> cbArticulo;
	private JLabel lbArticulo;
	private JLabel lbLogo;
	private JLabel lbMcDonalds;
	private JSpinner spUnidades;
	private JLabel lbUnidadesProducto;
	private JButton btAñadir;
	private JLabel lbPrecioPedido;
	private JButton btCancelar;
	private JButton btSiguiente;
	private JTextField txtPrecio;
	private JLabel lbUnidades;
	private JButton btEliminar;
	private JScrollPane spPanelPedido;
	private JTextArea txAreaPedido;
	private JToggleButton tbPedidoToggleButton;
	private JLabel lbImagenesArticulos;
	private JMenuBar menuBar;
	private JMenu mnPedido;
	private JMenu mnAyuda;
	private JMenuItem miNuevo;
	private JMenuItem miSalir;
	private JSeparator separator;
	private JMenuItem miAcercaDe;
	private JSeparator separator_1;
	private JMenuItem miContenidos;
	private JPanel pn;
	private JToggleButton btTodo;
	private JToggleButton btPostre;
	private JToggleButton btBebida;
	private JToggleButton btHamburguesas;
	private JToggleButton btComplemento;

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal(McDonalds mcDonalds) {
		ArgumentChecks.isNotNull(mcDonalds);

		this.macdonalds = mcDonalds;
		setTitle("McDonalds: Ventana Principal");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/logo.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 920, 514);
		this.setLocationRelativeTo(null);
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getCbArticulo());
		contentPane.add(getLbArticulo());
		contentPane.add(getLbLogo());
		contentPane.add(getLbMcDonalds());
		contentPane.add(getSpUnidades());
		contentPane.add(getLbUnidadesProducto());
		contentPane.add(getBtAñadir());
		contentPane.add(getLbPrecioPedido());
		contentPane.add(getBtCancelar());
		contentPane.add(getBtSiguiente());
		contentPane.add(getTxtPrecio());
		contentPane.add(getLbUnidades());
		contentPane.add(getBtEliminar());
		contentPane.add(getSpPanelPedido());
		contentPane.add(getTbPedidoToggleButton());
		contentPane.add(getLbImagenesArticulos());
		contentPane.add(getPn());

	}

	public void inicializar() {
		// inicializamos negocio
		macdonalds.inicializarPedido();
		// inicializamos interfaz
		getCbArticulo().setSelectedIndex(0);
		getSpUnidades().setValue(1);
		getTxtPrecio().setText("");
		getLbUnidades().setText("");
		getBtSiguiente().setEnabled(false);
		habilitarEliminar();
		setIconLbImagenes();
		updateListaPedido();
	}

	private JComboBox<Articulo> getCbArticulo() {
		if (cbArticulo == null) {
			cbArticulo = new JComboBox<Articulo>();
			cbArticulo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setIconLbImagenes();
					habilitarEliminar();
					mostrarUnidades();
				}
			});
			cbArticulo.setModel(new DefaultComboBoxModel<Articulo>(macdonalds.getArticulosCarta()));
			cbArticulo.setBounds(37, 265, 348, 31);
		}
		return cbArticulo;
	}

	private void habilitarEliminar() {
		Articulo articuloSeleccionado = (Articulo) this.getCbArticulo().getSelectedItem();

		try {
			macdonalds.getArticuloListado(articuloSeleccionado);
			this.getBtEliminar().setEnabled(true);
		} catch (ItemNotFoundException infe) {
			this.getBtEliminar().setEnabled(false);
		}

	}

	private JLabel getLbArticulo() {
		if (lbArticulo == null) {
			lbArticulo = new JLabel("Articulo:");
			lbArticulo.setDisplayedMnemonic('r');
			lbArticulo.setLabelFor(getCbArticulo());
			lbArticulo.setFont(new Font("Tahoma", Font.PLAIN, 11));
			lbArticulo.setBounds(37, 243, 87, 22);
		}
		return lbArticulo;
	}

	private JLabel getLbLogo() {
		if (lbLogo == null) {
			lbLogo = new JLabel("");
			lbLogo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/logo.png")));
			lbLogo.setBounds(37, 80, 156, 152);
		}
		return lbLogo;
	}

	private JLabel getLbMcDonalds() {
		if (lbMcDonalds == null) {
			lbMcDonalds = new JLabel("McDonald`s");
			lbMcDonalds.setFont(new Font("Arial Black", Font.PLAIN, 44));
			lbMcDonalds.setBounds(226, 149, 303, 46);
		}
		return lbMcDonalds;
	}

	private JSpinner getSpUnidades() {
		if (spUnidades == null) {
			spUnidades = new JSpinner();
			spUnidades
					.setModel(new SpinnerNumberModel(Integer.valueOf(1), Integer.valueOf(1), null, Integer.valueOf(1)));
			spUnidades.setBounds(395, 266, 60, 30);
		}
		return spUnidades;
	}

	private JLabel getLbUnidadesProducto() {
		if (lbUnidadesProducto == null) {
			lbUnidadesProducto = new JLabel("Unidades:");
			lbUnidadesProducto.setDisplayedMnemonic('u');
			lbUnidadesProducto.setLabelFor(getSpUnidades());
			lbUnidadesProducto.setBounds(395, 247, 124, 14);
		}
		return lbUnidadesProducto;
	}

	private JButton getBtAñadir() {
		if (btAñadir == null) {
			btAñadir = new JButton("A\u00F1adir");
			btAñadir.setMnemonic('a');
			btAñadir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					aniadirAPedido();
					habilitarEliminar();
					mostrarUnidades();
					updateListaPedido();
				}
			});
			btAñadir.setBackground(new Color(0, 128, 0));
			btAñadir.setForeground(new Color(255, 255, 255));
			btAñadir.setBounds(465, 265, 74, 30);
		}
		return btAñadir;
	}

	private void updateListaPedido() {
		String pedidoString = macdonalds.getPedidoToString();
		JTextArea ta = this.getTxAreaPedido();
		
		ta.setText(pedidoString);
	}
	private void mostrarUnidades() {
		lbUnidades = getLbUnidades();

		Articulo articuloSeleccionado = (Articulo) getCbArticulo().getSelectedItem();
		int unidades = 0;
		String text;
		try {

			Articulo articuloListado = macdonalds.getArticuloListado(articuloSeleccionado);
			unidades = articuloListado.getUnidades();

		} catch (ItemNotFoundException infe) {

		} finally {
			text = String.format("El numero de unidades del articulo ahora es: %d", unidades);

			lbUnidades.setText(text);
		}
	}

	private void aniadirAPedido() {
		Articulo articuloSeleccionado = (Articulo) getCbArticulo().getSelectedItem();
		int unidadesSolicitadas = (int) getSpUnidades().getValue();
		macdonalds.aniadirAPedido(articuloSeleccionado, unidadesSolicitadas);
		String precio = String.format("%.2f", macdonalds.getImportePedido());
		getTxtPrecio().setText(precio + " €");
		if (!getBtSiguiente().isEnabled()) {
			getBtSiguiente().setEnabled(true);
		}

	}

	private JLabel getLbPrecioPedido() {
		if (lbPrecioPedido == null) {
			lbPrecioPedido = new JLabel("Precio pedido");
			lbPrecioPedido.setBounds(395, 306, 134, 14);
		}
		return lbPrecioPedido;
	}

	private JButton getBtCancelar() {
		if (btCancelar == null) {
			btCancelar = new JButton("Cancelar");
			btCancelar.setMnemonic('c');
			btCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					inicializar();
				}
			});
			btCancelar.setForeground(new Color(255, 255, 255));
			btCancelar.setBackground(new Color(255, 0, 0));
			btCancelar.setBounds(691, 390, 89, 31);
		}
		return btCancelar;
	}

	private JButton getBtSiguiente() {
		if (btSiguiente == null) {
			btSiguiente = new JButton("Siguiente");
			btSiguiente.setMnemonic('s');
			btSiguiente.setEnabled(false);
			btSiguiente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					avanzarPagina();

				}
			});
			btSiguiente.setForeground(new Color(255, 255, 255));
			btSiguiente.setBackground(new Color(0, 128, 0));
			btSiguiente.setBounds(592, 390, 89, 31);
		}
		return btSiguiente;
	}

	private void avanzarPagina() {
		VentanaRegistro frame = new VentanaRegistro(this);
		frame.setVisible(true);
	}

	private JTextField getTxtPrecio() {
		if (txtPrecio == null) {
			txtPrecio = new JTextField();
			txtPrecio.setFocusable(false);
			txtPrecio.setEditable(false);
			txtPrecio.setBounds(395, 328, 74, 31);
			txtPrecio.setColumns(10);
		}
		return txtPrecio;
	}

	private JLabel getLbUnidades() {
		if (lbUnidades == null) {
			lbUnidades = new JLabel("");
			lbUnidades.setFont(new Font("Arial Black", Font.PLAIN, 12));
			lbUnidades.setForeground(new Color(0, 128, 0));
			lbUnidades.setBounds(37, 306, 348, 14);
		}
		return lbUnidades;
	}

	public McDonalds getMacdonalds() {
		return this.macdonalds;
	}

	private JButton getBtEliminar() {
		if (btEliminar == null) {
			btEliminar = new JButton("Eliminar");
			btEliminar.setMnemonic('e');
			btEliminar.setEnabled(false);
			btEliminar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					eliminar();
					habilitarEliminar();
					mostrarUnidades();
					updateListaPedido();
				}
			});
			btEliminar.setForeground(new Color(255, 255, 255));
			btEliminar.setBackground(new Color(255, 0, 0));
			btEliminar.setBounds(549, 265, 74, 31);
		}
		return btEliminar;
	}

	private void eliminar() {
		Articulo articuloEliminado = (Articulo) this.getCbArticulo().getSelectedItem();
		int unidades = (int) this.getSpUnidades().getValue();
		macdonalds.eliminar(articuloEliminado, unidades);

		String precio = String.format("%.2f", macdonalds.getImportePedido());
		getTxtPrecio().setText(precio + " €");

		if (!macdonalds.hayPedido()) {
			this.getBtSiguiente().setEnabled(false);
		}
	}
	private JScrollPane getSpPanelPedido() {
		if (spPanelPedido == null) {
			spPanelPedido = new JScrollPane();
			spPanelPedido.setVisible(false);
			spPanelPedido.setBounds(539, 80, 241, 152);
			spPanelPedido.setViewportView(getTxAreaPedido());
		}
		return spPanelPedido;
	}
	private JTextArea getTxAreaPedido() {
		if (txAreaPedido == null) {
			txAreaPedido = new JTextArea();
			txAreaPedido.setFocusable(false);
			txAreaPedido.setEditable(false);
		}
		return txAreaPedido;
	}
	private JToggleButton getTbPedidoToggleButton() {
		if (tbPedidoToggleButton == null) {
			tbPedidoToggleButton = new JToggleButton("Pedido");
			tbPedidoToggleButton.setMnemonic('P');
			tbPedidoToggleButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					habilitarPedidoPanel();
				}
			});
			tbPedidoToggleButton.setBackground(new Color(255, 255, 255));
			tbPedidoToggleButton.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/pedido.png")));
			tbPedidoToggleButton.setFont(new Font("Arial Black", Font.PLAIN, 16));
			tbPedidoToggleButton.setBounds(604, 10, 176, 60);
		}
		return tbPedidoToggleButton;
	}
	
	private void habilitarPedidoPanel() {
		JScrollPane sp = this.getSpPanelPedido();
		if(sp.isVisible()) {
			sp.setVisible(false);
		}
		else {
			sp.setVisible(true);
		}
	}
	private void setIconLbImagenes() {
		Articulo articuloSeleccionado = (Articulo) this.getCbArticulo().getSelectedItem();
		String recursoImagen = "/img/"+articuloSeleccionado.getCodigo()+".png";
		lbImagenesArticulos.setIcon(new ImageIcon(VentanaPrincipal.class.getResource(recursoImagen)));
	}
	private JLabel getLbImagenesArticulos() {
		if (lbImagenesArticulos == null) {
			lbImagenesArticulos = new JLabel("");
			setIconLbImagenes();
			lbImagenesArticulos.setBounds(166, 328, 124, 136);
		}
		return lbImagenesArticulos;
	}
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnPedido());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}
	private JMenu getMnPedido() {
		if (mnPedido == null) {
			mnPedido = new JMenu("Pedido");
			mnPedido.setMnemonic('e');
			mnPedido.add(getMiNuevo());
			mnPedido.add(getSeparator());
			mnPedido.add(getMiSalir());
		}
		return mnPedido;
	}
	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setMnemonic('y');
			mnAyuda.add(getMiContenidos());
			mnAyuda.add(getSeparator_1());
			mnAyuda.add(getMiAcercaDe());
		}
		return mnAyuda;
	}
	private JMenuItem getMiNuevo() {
		if (miNuevo == null) {
			miNuevo = new JMenuItem("Nuevo");
			miNuevo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					inicializar();
				}
			});
			miNuevo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
			miNuevo.setMnemonic('n');
		}
		return miNuevo;
	}
	private JMenuItem getMiSalir() {
		if (miSalir == null) {
			miSalir = new JMenuItem("Salir");
			miSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			miSalir.setMnemonic('s');
		}
		return miSalir;
	}
	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}
	private JMenuItem getMiAcercaDe() {
		if (miAcercaDe == null) {
			miAcercaDe = new JMenuItem("Acerca de");
			miAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Aplicacion para TPV de comida rapida \n Realizada por David Feito Campo\n"
							+ "Practicas CPM 25-26  \n EII Oviedo", "Acerca de", JOptionPane.INFORMATION_MESSAGE);
				}
			});
			miAcercaDe.setMnemonic('a');
		}
		return miAcercaDe;
	}
	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}
	private JMenuItem getMiContenidos() {
		if (miContenidos == null) {
			miContenidos = new JMenuItem("Contenidos");
			miContenidos.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
			miContenidos.setMnemonic('c');
			miContenidos.setEnabled(false);
		}
		return miContenidos;
	}
	private JPanel getPn() {
		if (pn == null) {
			pn = new JPanel();
			pn.setBorder(new SoftBevelBorder(BevelBorder.RAISED, new Color(255, 182, 47), new Color(255, 182, 47), new Color(255, 182, 47), new Color(255, 182, 47)));
			pn.setBounds(809, 0, 95, 453);
			pn.setLayout(new GridLayout(5, 0, 0, 0));
			pn.add(getBtTodo());
			pn.add(getBtHamburguesas());
			pn.add(getBtBebida());
			pn.add(getBtComplemento());
			pn.add(getBtPostre());
		}
		return pn;
	}
	private JToggleButton getBtTodo() {
		if (btTodo == null) {
			btTodo = new JToggleButton("Todo");
			btTodo.setHorizontalTextPosition(SwingConstants.CENTER);
			btTodo.setVerticalTextPosition(SwingConstants.BOTTOM);
			btTodo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Todos.png")));
			btTodo.setFont(new Font("Tahoma", Font.PLAIN, 10));
			btTodo.setMnemonic('t');
			btTodo.setMargin(new Insets(0, 0, 0, 0));
		}
		return btTodo;
	}
	private JToggleButton getBtPostre() {
		if (btPostre == null) {
			btPostre = new JToggleButton("Postre");
			btPostre.setHorizontalTextPosition(SwingConstants.CENTER);
			btPostre.setVerticalTextPosition(SwingConstants.BOTTOM);
			btPostre.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Postre.png")));
			btPostre.setFont(new Font("Tahoma", Font.PLAIN, 10));
			btPostre.setMnemonic('o');
			btPostre.setMargin(new Insets(0, 0, 0, 0));
		}
		return btPostre;
	}
	private JToggleButton getBtBebida() {
		if (btBebida == null) {
			btBebida = new JToggleButton("Bebida");
			btBebida.setHorizontalTextPosition(SwingConstants.CENTER);
			btBebida.setVerticalTextPosition(SwingConstants.BOTTOM);
			btBebida.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Bebida.png")));
			btBebida.setFont(new Font("Tahoma", Font.PLAIN, 10));
			btBebida.setMnemonic('b');
			btBebida.setMargin(new Insets(0, 0, 0, 0));
		}
		return btBebida;
	}
	private JToggleButton getBtHamburguesas() {
		if (btHamburguesas == null) {
			btHamburguesas = new JToggleButton("Hamburguesas");
			btHamburguesas.setHorizontalTextPosition(SwingConstants.CENTER);
			btHamburguesas.setVerticalTextPosition(SwingConstants.BOTTOM);
			btHamburguesas.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Hamburguesa.png")));
			btHamburguesas.setFont(new Font("Tahoma", Font.PLAIN, 10));
			btHamburguesas.setMnemonic('h');
			btHamburguesas.setMargin(new Insets(0, 0, 0, 0));
		}
		return btHamburguesas;
	}
	private JToggleButton getBtComplemento() {
		if (btComplemento == null) {
			btComplemento = new JToggleButton("Complemento");
			btComplemento.setHorizontalTextPosition(SwingConstants.CENTER);
			btComplemento.setVerticalTextPosition(SwingConstants.BOTTOM);
			btComplemento.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Complemento.png")));
			btComplemento.setFont(new Font("Tahoma", Font.PLAIN, 10));
			btComplemento.setMnemonic('c');
			btComplemento.setMargin(new Insets(0, 0, 0, 0));
		}
		return btComplemento;
	}
}
