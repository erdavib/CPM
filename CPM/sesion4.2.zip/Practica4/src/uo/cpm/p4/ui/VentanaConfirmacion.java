package uo.cpm.p4.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import uo.cpm.p3.util.check.ArgumentChecks;
import uo.cpm.p4.service.McDonalds;

public class VentanaConfirmacion extends JDialog {

	private static final long serialVersionUID = 1L;
	private McDonalds macdonalds;
	private VentanaRegistro ventanaRegistro;
	private JLabel lbIcono;
	private JLabel lbDialogoPrincipal;
	private JLabel lbCodigoRecogida;
	private JTextField txtCodigo;
	private JButton btFinalizar;
	private JTextField txtPrecioFinal;
	private JLabel lbPrecioFinal;


	/**
	 * Create the dialog.
	 */
	public VentanaConfirmacion(VentanaRegistro vr) {
		ArgumentChecks.isNotNull(vr);
		this.ventanaRegistro = vr;
		this.macdonalds =ventanaRegistro.getMacdonalds();
		getContentPane().setBackground(new Color(255, 255, 255));
		getContentPane().setLayout(null);
		getContentPane().add(getLbIcono());
		getContentPane().add(getLbDialogoPrincipal());
		getContentPane().add(getLbCodigoRecogida());
		getContentPane().add(getTxtCodigo());
		getContentPane().add(getBtFinalizar());
		getContentPane().add(getTxtPrecioFinal());
		getContentPane().add(getLbPrecioFinal());
		setBackground(new Color(255, 255, 255));
		setTitle("McDonalds: Ventana de confirmacion");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaConfirmacion.class.getResource("/img/logo.png")));
		setBounds(100, 100, 555, 295);

	}

	private JLabel getLbIcono() {
		if (lbIcono == null) {
			lbIcono = new JLabel("");
			lbIcono.setIcon(new ImageIcon(VentanaConfirmacion.class.getResource("/img/ok.png")));
			lbIcono.setBounds(20, 46, 55, 63);
		}
		return lbIcono;
	}
	private JLabel getLbDialogoPrincipal() {
		if (lbDialogoPrincipal == null) {
			lbDialogoPrincipal = new JLabel("Pulse Finalizar para confirmar su pedido");
			lbDialogoPrincipal.setFont(new Font("Arial Black", Font.PLAIN, 20));
			lbDialogoPrincipal.setBounds(85, 46, 452, 49);
		}
		return lbDialogoPrincipal;
	}
	private JLabel getLbCodigoRecogida() {
		if (lbCodigoRecogida == null) {
			lbCodigoRecogida = new JLabel("El codigo de recogida es: ");
			lbCodigoRecogida.setLabelFor(getTxtCodigo());
			lbCodigoRecogida.setBounds(85, 109, 122, 14);
		}
		return lbCodigoRecogida;
	}
	private JTextField getTxtCodigo() {
		if (txtCodigo == null) {
			txtCodigo = new JTextField();
			txtCodigo.setFocusable(false);
			txtCodigo.setBackground(new Color(192, 192, 192));
			txtCodigo.setEditable(false);
			txtCodigo.setBounds(231, 106, 86, 34);
			txtCodigo.setColumns(10);
			txtCodigo.setText(macdonalds.getCodigoPedido());
		}
		return txtCodigo;
	}
	private JButton getBtFinalizar() {
		if (btFinalizar == null) {
			btFinalizar = new JButton("Finalizar");
			btFinalizar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					finalizar();
				}
			});
			btFinalizar.setBounds(440, 211, 89, 34);
		}
		return btFinalizar;
	}
	private void finalizar() {
		macdonalds.grabarPedido();
		JOptionPane.showMessageDialog(null, "Su pedido se ha realizado");
		dispose();
		ventanaRegistro.dispose();
		VentanaPrincipal vp = ventanaRegistro.getVentanaPrincipal();
		vp.inicializar();
	}
	private JTextField getTxtPrecioFinal() {
		if (txtPrecioFinal == null) {
			txtPrecioFinal = new JTextField();
			String precioFinal = String.format("%.2f", macdonalds.getImportePedido());
			txtPrecioFinal.setText(precioFinal+ " €");
			txtPrecioFinal.setBackground(new Color(192, 192, 192));
			txtPrecioFinal.setFocusable(false);
			txtPrecioFinal.setEditable(false);
			txtPrecioFinal.setBounds(231, 151, 86, 34);
			txtPrecioFinal.setColumns(10);
		}
		return txtPrecioFinal;
	}
	private JLabel getLbPrecioFinal() {
		if (lbPrecioFinal == null) {
			lbPrecioFinal = new JLabel("Precio final:");
			lbPrecioFinal.setBounds(85, 154, 122, 14);
		}
		return lbPrecioFinal;
	}
}
