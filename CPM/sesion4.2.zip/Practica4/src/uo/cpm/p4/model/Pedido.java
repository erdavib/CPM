package uo.cpm.p4.model;

import java.util.ArrayList;
import java.util.List;

import uo.cpm.p4.exceptions.ItemNotFoundException;
import uo.cpm.p4.util.FileUtil;

/**
 * Clase que se encarga de almacenar todos los datos de un pedido
 */
public class Pedido {


	/**
	 * Precio por defecto de la bolsa en caso de que el pedido sea para llevar
	 */
	public static final float PRECIO_BOLSA=0.15f;
	/**
	 * Tipo asociado a un pedido para consumir en el local
	 */
	public static final boolean TIPO_LOCAL = true;
	/**
	 * Tipo asociado a un pedido para llevar
	 */
	public static final boolean TIPO_LLEVAR = false;
	/**
	 * Longitud que tiene un codigo de un pedido por defecto
	 */
	public static final int LONGITUD_CODIGO = 8;

	private List<Articulo> listaPedido;
	private String codigo;
	private float importe;
	private boolean local;
	private Cliente cliente;

	public Pedido() {
		listaPedido = new ArrayList<Articulo>();
		inicializar();
	}

	/**
	 * Genera un codigo aleatorio para el pedido, por defecto el importe es 0, el
	 * pedido es para consumir en el local, y el cliente inexistente. Inicializa la
	 * lista de articulos vacía
	 */
	public void inicializar() {
		listaPedido.clear();
		generarCodigo();
		setImporte(0);
		setLocal(TIPO_LOCAL);
		setCliente(null);
	}

	/**
	 * Agrega al pedido un numero de unidades de un articulo.
	 * Calcula el importe total del pedido de nuevo cada vez que se agrega un articulo
	 * @param articuloDelCatalogo Articulo a añadir
	 * @param unidades            Unidades a añadir
	 */
	public void add(Articulo articuloDelCatalogo, int unidades) {
		Articulo articuloEnPedido = null;

		for (Articulo a : listaPedido) {
			if (a.getCodigo().equals(articuloDelCatalogo.getCodigo())) {
				articuloEnPedido = a;
				articuloEnPedido.setUnidades(articuloEnPedido.getUnidades() + unidades);
				break;
			}
		}

		if (articuloEnPedido == null) {
			articuloEnPedido = new Articulo(articuloDelCatalogo);
			articuloEnPedido.setUnidades(unidades);
			listaPedido.add(articuloEnPedido);
		}
		calcularImporte();
	}

	/**
	 * Calcula el importe total del pedido
	 */
	private void calcularImporte() {
		importe = 0;
		for (Articulo a : listaPedido)
			importe += a.getPrecio() * a.getUnidades();
		if(!isLocal()) {
			importe+=PRECIO_BOLSA;
		}
	}

	/**
	 * Guarda el pedido en un fichero
	 */
	public void grabarPedido() {
		FileUtil.saveToFile(this);
	}
	
	/**
	 * Recibe por parametro un articulo y si coincide en denominación y precio con uno del pedido
	 * devuelve el articulo del pedido correspondiente, conforme al metodo boolean equals() de Articulo
	 * Lanza:	NullPointerException de recibir un parametro null
	 * 			ItemNotFoundException si recibe un Articulo que no se encuentra en el pedido
	 * @param otro Articulo con denominacion a devolver
	 * @return Articulo del pedido con la denominacion recibida
	 */
	public int getIndexArticulo(Articulo otro) {
		
		if(itemIsListed(otro)) {
			for(int i=0; i<listaPedido.size();i++) {
				Articulo actual = listaPedido.get(i);
				if(actual.equals(otro)) {
					return i;
				}
			}
		}
		
		throw new ItemNotFoundException("El articulo no pudo ser encontrado");
	}

	private boolean itemIsListed(Articulo otro) {
		
		List<Articulo> listaPedido = getListaPedido();
		
		for(int i=0; i<listaPedido.size();i++) {
			Articulo actual = listaPedido.get(i);
			if(actual.equals(otro)) {
				return true;
			}
		}
		return false;
	}
	/**
	 * Devuelve una copia de la lista de pedidos que se tiene por atributo
	 * @return ArrayList Descrito
	 */
	public List<Articulo> getListaPedido() {
		return new ArrayList<Articulo>(listaPedido);
	}

	public void setListaPedido(List<Articulo> listaPedido) {
		this.listaPedido = listaPedido;
	}

	public String getCodigo() {
		return codigo;
	}

	public float getImporte() {
		return importe;
	}

	public void setImporte(float importe) {
		this.importe = importe;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public void setLocal(boolean tipo) {
		local = tipo;
	}

	public boolean isLocal() {
		return local;
	}
	
	public void generarCliente(String nombreYApellidos, int anios, String password) {
		Cliente cliente = new Cliente(nombreYApellidos, anios, password);
		setCliente(cliente);
	}

	/**
	 * Genera un codigo aleatorio para el pedido de longitud establecida por la constante asociada LONGITUD_CODIGO
	 */
	public void generarCodigo() {
		codigo = "";// Se inicializa el código como cadena vacía
		String base = "0123456789abcdefghijklmnopqrstuvwxyz";
		int longitudCodigo = LONGITUD_CODIGO;
		for (int i = 0; i < longitudCodigo; i++) // (Sería mejor usar un stringBuilder
			// Se elige un índice aleatorio dentro de la base
			codigo += base.charAt((int) (Math.random() * (base.length())));
		// Se agrega el carácter elegido al código
	}

	public void actualizarTipoPedido(boolean local) {
		setLocal(local);
		calcularImporte();
	}

	public void eliminar(Articulo articuloEliminado, int unidades) {
		
		if(itemIsListed(articuloEliminado)) {
			int index = getIndexArticulo(articuloEliminado);
			Articulo articuloListado = listaPedido.get(index);
			int unidadesListadas = articuloListado.getUnidades();
			
			if(unidadesListadas-unidades<=0) {
				listaPedido.remove(index);
			}
			else {
				articuloListado.setUnidades(unidadesListadas-unidades);
			}
			calcularImporte();
		}
	}

	public Articulo getArticuloListado(Articulo otro) {
		return listaPedido.get(getIndexArticulo(otro));
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		for(Articulo a: listaPedido) {
			sb.append(a.toStringListado());
			sb.append("\n");
		}
		return sb.toString();
	}

}
