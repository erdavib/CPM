package uo.cpm.p4.console;

public class McDonaldsApp {
	public void run() {
		
	}
}
