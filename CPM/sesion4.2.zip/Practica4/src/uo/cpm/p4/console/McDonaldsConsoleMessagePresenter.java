package uo.cpm.p4.console;

import uo.cpm.p3.util.check.ArgumentChecks;
import uo.cpm.p3.util.console.Console;
import uo.cpm.p4.console.interfaces.McDonaldsMessagePresenter;
import uo.cpm.p4.model.Articulo;

/**
 * Clase que se encarga de mostrar por consola mensajes que no requieren la interaccion del usuario
 * a color.
 */
public class McDonaldsConsoleMessagePresenter implements McDonaldsMessagePresenter{
	
	private void println(String message) {
		ArgumentChecks.isNotNull(message);
		Console.println(message);
	}

	@Override
	public void showCatalog(Articulo[] list) {
		for(int i=0;i<list.length;i++) {
			println(i+" - "+list[i].getDenominacion());
		}
		
	}

	@Override
	public void showPrice(float f) {
		println(Float.toString(f));
		
	}
}
