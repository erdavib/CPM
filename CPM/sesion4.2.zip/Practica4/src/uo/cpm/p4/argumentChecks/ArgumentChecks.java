package uo.cpm.p4.argumentChecks;

public class ArgumentChecks {
	/**
	 * Comprueba que el objeto pasado como parametro sea o no null
	 * de serlo, lanzará la correspondiente excepción
	 * @param o Objeto evaluado
	 */
	public void checkNull(Object o) {
		if (o==null) {
			throw new NullPointerException();
		}
	}
}
