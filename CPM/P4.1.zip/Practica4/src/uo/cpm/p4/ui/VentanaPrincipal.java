package uo.cpm.p4.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;

import uo.cpm.p3.util.check.ArgumentChecks;
import uo.cpm.p4.exceptions.ItemNotFoundException;
import uo.cpm.p4.model.Articulo;
import uo.cpm.p4.service.McDonalds;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JToggleButton;

public class VentanaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private McDonalds macdonalds;
	private JPanel contentPane;
	private JComboBox<Articulo> cbArticulo;
	private JLabel lbArticulo;
	private JLabel lbLogo;
	private JLabel lbMcDonalds;
	private JSpinner spUnidades;
	private JLabel lbUnidadesProducto;
	private JButton btAñadir;
	private JLabel lbPrecioPedido;
	private JButton btCancelar;
	private JButton btSiguiente;
	private JTextField txtPrecio;
	private JLabel lbUnidades;
	private JButton btEliminar;
	private JScrollPane spPanelPedido;
	private JTextArea txAreaPedido;
	private JToggleButton tbPedidoToggleButton;

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal(McDonalds mcDonalds) {
		ArgumentChecks.isNotNull(mcDonalds);

		this.macdonalds = mcDonalds;
		setTitle("McDonalds: Ventana Principal");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/logo.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 806, 468);
		this.setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getCbArticulo());
		contentPane.add(getLbArticulo());
		contentPane.add(getLbLogo());
		contentPane.add(getLbMcDonalds());
		contentPane.add(getSpUnidades());
		contentPane.add(getLbUnidadesProducto());
		contentPane.add(getBtAñadir());
		contentPane.add(getLbPrecioPedido());
		contentPane.add(getBtCancelar());
		contentPane.add(getBtSiguiente());
		contentPane.add(getTxtPrecio());
		contentPane.add(getLbUnidades());
		contentPane.add(getBtEliminar());
		contentPane.add(getSpPanelPedido());
		contentPane.add(getTbPedidoToggleButton());

	}

	public void inicializar() {
		// inicializamos negocio
		macdonalds.inicializarPedido();
		// inicializamos interfaz
		getCbArticulo().setSelectedIndex(0);
		getSpUnidades().setValue(1);
		getTxtPrecio().setText("");
		getLbUnidades().setText("");
		getBtSiguiente().setEnabled(false);

	}

	private JComboBox<Articulo> getCbArticulo() {
		if (cbArticulo == null) {
			cbArticulo = new JComboBox<Articulo>();
			cbArticulo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					habilitarEliminar();
					mostrarUnidades();
				}
			});
			cbArticulo.setModel(new DefaultComboBoxModel<Articulo>(macdonalds.getArticulosCarta()));
			cbArticulo.setBounds(47, 265, 348, 31);
		}
		return cbArticulo;
	}

	private void habilitarEliminar() {
		Articulo articuloSeleccionado = (Articulo) this.getCbArticulo().getSelectedItem();

		try {
			macdonalds.getArticuloListado(articuloSeleccionado);
			this.getBtEliminar().setEnabled(true);
		} catch (ItemNotFoundException infe) {
			this.getBtEliminar().setEnabled(false);
		}

	}

	private JLabel getLbArticulo() {
		if (lbArticulo == null) {
			lbArticulo = new JLabel("Articulo");
			lbArticulo.setFont(new Font("Tahoma", Font.PLAIN, 11));
			lbArticulo.setBounds(37, 243, 87, 22);
		}
		return lbArticulo;
	}

	private JLabel getLbLogo() {
		if (lbLogo == null) {
			lbLogo = new JLabel("");
			lbLogo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/logo.png")));
			lbLogo.setBounds(37, 80, 156, 152);
		}
		return lbLogo;
	}

	private JLabel getLbMcDonalds() {
		if (lbMcDonalds == null) {
			lbMcDonalds = new JLabel("McDonald`s");
			lbMcDonalds.setFont(new Font("Arial Black", Font.PLAIN, 44));
			lbMcDonalds.setBounds(226, 149, 303, 46);
		}
		return lbMcDonalds;
	}

	private JSpinner getSpUnidades() {
		if (spUnidades == null) {
			spUnidades = new JSpinner();
			spUnidades
					.setModel(new SpinnerNumberModel(Integer.valueOf(1), Integer.valueOf(1), null, Integer.valueOf(1)));
			spUnidades.setBounds(395, 266, 40, 30);
		}
		return spUnidades;
	}

	private JLabel getLbUnidadesProducto() {
		if (lbUnidadesProducto == null) {
			lbUnidadesProducto = new JLabel("Unidades");
			lbUnidadesProducto.setBounds(395, 247, 124, 14);
		}
		return lbUnidadesProducto;
	}

	private JButton getBtAñadir() {
		if (btAñadir == null) {
			btAñadir = new JButton("A\u00F1adir");
			btAñadir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					aniadirAPedido();
					habilitarEliminar();
					mostrarUnidades();
					updateListaPedido();
				}
			});
			btAñadir.setBackground(new Color(0, 128, 0));
			btAñadir.setForeground(new Color(255, 255, 255));
			btAñadir.setBounds(445, 265, 74, 30);
		}
		return btAñadir;
	}

	private void updateListaPedido() {
		String pedidoString = macdonalds.getPedidoToString();
		JTextArea ta = this.getTxAreaPedido();
		
		ta.setText(pedidoString);
	}
	private void mostrarUnidades() {
		lbUnidades = getLbUnidades();

		Articulo articuloSeleccionado = (Articulo) getCbArticulo().getSelectedItem();
		int unidades = 0;
		String text;
		try {

			Articulo articuloListado = macdonalds.getArticuloListado(articuloSeleccionado);
			unidades = articuloListado.getUnidades();

		} catch (ItemNotFoundException infe) {

		} finally {
			text = String.format("El numero de unidades del articulo ahora es: %d", unidades);

			lbUnidades.setText(text);
		}
	}

	private void aniadirAPedido() {
		Articulo articuloSeleccionado = (Articulo) getCbArticulo().getSelectedItem();
		int unidadesSolicitadas = (int) getSpUnidades().getValue();
		macdonalds.aniadirAPedido(articuloSeleccionado, unidadesSolicitadas);
		String precio = String.format("%.2f", macdonalds.getImportePedido());
		getTxtPrecio().setText(precio + " €");
		if (!getBtSiguiente().isEnabled()) {
			getBtSiguiente().setEnabled(true);
		}

	}

	private JLabel getLbPrecioPedido() {
		if (lbPrecioPedido == null) {
			lbPrecioPedido = new JLabel("Precio pedido");
			lbPrecioPedido.setBounds(395, 306, 134, 14);
		}
		return lbPrecioPedido;
	}

	private JButton getBtCancelar() {
		if (btCancelar == null) {
			btCancelar = new JButton("Cancelar");
			btCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					inicializar();
				}
			});
			btCancelar.setForeground(new Color(255, 255, 255));
			btCancelar.setBackground(new Color(255, 0, 0));
			btCancelar.setBounds(691, 390, 89, 31);
		}
		return btCancelar;
	}

	private JButton getBtSiguiente() {
		if (btSiguiente == null) {
			btSiguiente = new JButton("Siguiente");
			btSiguiente.setEnabled(false);
			btSiguiente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					avanzarPagina();

				}
			});
			btSiguiente.setForeground(new Color(255, 255, 255));
			btSiguiente.setBackground(new Color(0, 128, 0));
			btSiguiente.setBounds(592, 390, 89, 31);
		}
		return btSiguiente;
	}

	private void avanzarPagina() {
		VentanaRegistro frame = new VentanaRegistro(this);
		frame.setVisible(true);
	}

	private JTextField getTxtPrecio() {
		if (txtPrecio == null) {
			txtPrecio = new JTextField();
			txtPrecio.setFocusable(false);
			txtPrecio.setEditable(false);
			txtPrecio.setBounds(395, 328, 74, 31);
			txtPrecio.setColumns(10);
		}
		return txtPrecio;
	}

	private JLabel getLbUnidades() {
		if (lbUnidades == null) {
			lbUnidades = new JLabel("");
			lbUnidades.setFont(new Font("Arial Black", Font.PLAIN, 12));
			lbUnidades.setForeground(new Color(255, 0, 0));
			lbUnidades.setBounds(37, 306, 348, 14);
		}
		return lbUnidades;
	}

	public McDonalds getMacdonalds() {
		return this.macdonalds;
	}

	private JButton getBtEliminar() {
		if (btEliminar == null) {
			btEliminar = new JButton("Eliminar");
			btEliminar.setEnabled(false);
			btEliminar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					eliminar();
					habilitarEliminar();
					mostrarUnidades();
					updateListaPedido();
				}
			});
			btEliminar.setForeground(new Color(255, 255, 255));
			btEliminar.setBackground(new Color(255, 0, 0));
			btEliminar.setBounds(529, 265, 74, 31);
		}
		return btEliminar;
	}

	private void eliminar() {
		Articulo articuloEliminado = (Articulo) this.getCbArticulo().getSelectedItem();
		int unidades = (int) this.getSpUnidades().getValue();
		macdonalds.eliminar(articuloEliminado, unidades);

		String precio = String.format("%.2f", macdonalds.getImportePedido());
		getTxtPrecio().setText(precio + " €");

		if (macdonalds.getImportePedido() == 0) {
			this.getBtSiguiente().setEnabled(false);
		}
	}
	private JScrollPane getSpPanelPedido() {
		if (spPanelPedido == null) {
			spPanelPedido = new JScrollPane();
			spPanelPedido.setVisible(false);
			spPanelPedido.setBounds(539, 80, 241, 152);
			spPanelPedido.setViewportView(getTxAreaPedido());
		}
		return spPanelPedido;
	}
	private JTextArea getTxAreaPedido() {
		if (txAreaPedido == null) {
			txAreaPedido = new JTextArea();
			txAreaPedido.setFocusable(false);
			txAreaPedido.setEditable(false);
		}
		return txAreaPedido;
	}
	private JToggleButton getTbPedidoToggleButton() {
		if (tbPedidoToggleButton == null) {
			tbPedidoToggleButton = new JToggleButton("Pedido");
			tbPedidoToggleButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					habilitarPedidoPanel();
				}
			});
			tbPedidoToggleButton.setBackground(new Color(255, 255, 255));
			tbPedidoToggleButton.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/pedido.png")));
			tbPedidoToggleButton.setFont(new Font("Arial Black", Font.PLAIN, 16));
			tbPedidoToggleButton.setBounds(604, 10, 176, 60);
		}
		return tbPedidoToggleButton;
	}
	
	private void habilitarPedidoPanel() {
		JScrollPane sp = this.getSpPanelPedido();
		if(sp.isVisible()) {
			sp.setVisible(false);
		}
		else {
			sp.setVisible(true);
		}
	}
}
