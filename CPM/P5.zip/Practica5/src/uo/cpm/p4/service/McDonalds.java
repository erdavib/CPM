package uo.cpm.p4.service;


import java.time.LocalDateTime;

import uo.cpm.p4.model.Articulo;
import uo.cpm.p4.model.Carta;
import uo.cpm.p4.model.Cliente;
import uo.cpm.p4.model.Pedido;

/**
 * Clase principal de servicio que organiza a las clases del modelo
 * se encarga de comunicar a las clases del modelo con la interfaz de usuario
 */
public class McDonalds {
	
	Carta carta = new Carta();
	Pedido pedido = new Pedido(); 
	
	/**
	 * Constructor que además inicializa el pedido en la clase Pedido
	 */
	public McDonalds() {
		inicializarPedido();
	}

	/**
	 * Devuelve un array que contiene los articulos disponibles en la carta
	 * @return Articulo[] Array descrito
	 */
	public Articulo[] getArticulosCarta() {
		return carta.getArticulos();
	}
	
	/**
	 * Inicializa el pedido en la clase Pedido
	 */
	public void inicializarPedido() {
		pedido.inicializar();
	}
	
	public boolean hayPedido() {
		return pedido.getListaPedido().size()!=0;
	}
	
	/**
	 * Retorna el codigo del pedido
	 * @return String Descrito
	 */
	public String getCodigoPedido() {
		return pedido.getCodigo();
	}

	/**
	 * Agrega al pedido el articulo pasado como parametro con sus unidades
	 * @param articulo Articulo a añadir
	 * @param unidades Unidades a añadir
	 */
	public void aniadirAPedido(Articulo articulo, int unidades) {
		pedido.add(articulo, unidades);
	}

	/**
	 * Retorna el valor del importe del pedido como un float
	 * @return float Importe del pedido
	 */
	public float getImportePedido() {
		return pedido.getImporte();
	}
	
	/**
	 * Guarda al cliente pasado mediante los parametros
	 * @param nombre Nombre y apellidos del cliente
	 * @param anio Anio de nacimiento del cliente
	 * @param password Contraseña escogida por el cliente
	 */
	public void guardarCliente(String nombre, int anio, String password) {
		pedido.setCliente(new Cliente(nombre, anio, password));
	}
	
	/**
	 * Actualiza el tipo de pedido
	 * @param local booleano, conforme a las constantes de la clase Pedido TIPO_LOCAL y TIPO_LLEVAR
	 */
	public void actualizarTipoPedido (boolean local) {
		pedido.actualizarTipoPedido(local);
	}
	
	/**
	 * Devuelve el tipo del pedido
	 * @return boolean Conforme a las constantes de la clase Pedido TIPO_LOCAL y TIPO_LLEVAR
	 */
	public boolean getTipoPedido() {
		return pedido.isLocal();
	}
	/**
	 * Graba el pedido en un fichero
	 */
	public void grabarPedido() {
		pedido.grabarPedido();
	}
	
	public void generarCliente(String nombreYApellidos, int anios, String password) {
		pedido.generarCliente(nombreYApellidos, anios, password);
	}
	
	/**
	 * Recibe por parametro un articulo y si coincide en denominación y precio con uno del pedido
	 * devuelve el articulo del pedido correspondiente, conforme al metodo boolean equals() de Articulo
	 * Lanza:	NullPointerException de recibir un parametro null
	 * 			ItemNotFoundException si recibe un Articulo que no se encuentra en el pedido
	 * @param otro Articulo con denominacion a devolver
	 * @return Articulo del pedido con la denominacion recibida
	 */
	public Articulo getArticuloListado(Articulo otro) {
		return pedido.getArticuloListado(otro);
	}
	
	/**
	 * Devuelve una lista que contiene todos los anios que puede escoger un cliente al registrarse
	 * @return	String[] Descrito
	 */
	public String[] getRangoAnios() {
	    int anioActual = LocalDateTime.now().getYear();
	    int rango = Cliente.EDAD_MAX-Cliente.EDAD_MIN;
		String[]anios = new String[rango];
		for (int i=0;i<rango;i++)
			anios[i] = String.valueOf((anioActual-Cliente.EDAD_MIN)-i);
		return anios;
	}

	public void eliminar(Articulo articuloEliminado, int unidades) {
		pedido.eliminar(articuloEliminado, unidades);
	}

	public String getPedidoToString() {
		return pedido.toString();
	}

	public void actualizarFiltros(boolean[] listaFiltros) {
		carta.actualizarFiltros(listaFiltros);
	}

	public Articulo[] getArticulosCartaFiltrados() {
		return carta.getArticulosCartaFiltrados();
	}
}
