package uo.cpm.p4.model.enumerations;

public enum FiltroArticulo {
	TODO,
	HAMBURGUESAS,
	BEBIDA,
	COMPLEMENTO,
	POSTRE
}
