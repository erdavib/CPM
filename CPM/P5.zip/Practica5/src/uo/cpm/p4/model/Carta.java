package uo.cpm.p4.model;

import java.util.*;

import uo.cpm.p4.exceptions.FilterNotFoundException;
import uo.cpm.p4.model.enumerations.FiltroArticulo;
import uo.cpm.p4.util.FileUtil;

/**
 * Clase encargada de cargar y devolver la lista de articulos disponibles, que se encuentra en un fichero
 */
public class Carta {

	/**
	 * Fichero en el que se encuentran por defecto los articulos a cargar
	 */
	private static final String FICHERO_ARTICULOS = "files/articulos.dat";
	/**
	 * Lista que establece el orden en el que deberian de recogerse los valores de verdad de los filtros en la interfaz correspondiente.
	 */
	public static final List<FiltroArticulo> ORDEN_FILTROS = new ArrayList<FiltroArticulo>(Arrays.asList(
			FiltroArticulo.TODO,
			FiltroArticulo.HAMBURGUESAS, 
			FiltroArticulo.BEBIDA, 
			FiltroArticulo.COMPLEMENTO, 
			FiltroArticulo.POSTRE));
	
	private List<Articulo> listaArticulos = null;
	private List<Articulo> listaArticulosFiltrada = new ArrayList<Articulo>();

	public Carta() {
		listaArticulos = new ArrayList<Articulo>();
		cargarArticulos();
	}

	private void cargarArticulos() {
		FileUtil.loadFile(FICHERO_ARTICULOS, listaArticulos);
	}

	/**
	 * @return Articulo[] Copia del array que se tiene como atributo
	 */
	public Articulo[] getArticulos() {
		Articulo[] articulos = listaArticulos.toArray(new Articulo[listaArticulos.size()]);
		return articulos;
	}

	public Articulo[] getArticulosCartaFiltrados() {
		return listaArticulosFiltrada.toArray(new Articulo[listaArticulosFiltrada.size()]);
	}
	
	/**
	 * Metodo que recibe como parametro una lista de filtros seleccionados en una interfaz,
	 * recorre esta lista junto con la lista de filtros en su respectivo orden (Fijado por la constante
	 * ORDEN_FILTROS) si y solo si coinciden en tamaño.
	 * 
	 * Para cada par Filtro-Booleano, si el boolean es true, llama a la funcion que administra el filtro.
	 * 
	 * Se presupone que la lista de boolean recibida está sincronizada con la lista de filtros.
	 * 
	 * @param listaFiltrosSeleccionados
	 */
	public void actualizarFiltros(boolean[] listaFiltrosSeleccionados) {
		listaArticulosFiltrada.clear();
		if (listaFiltrosSeleccionados.length == ORDEN_FILTROS.size()) {
			for(int i=0; i<ORDEN_FILTROS.size();i++) {
				FiltroArticulo filtro = ORDEN_FILTROS.get(i);
				boolean isSelected = listaFiltrosSeleccionados[i];
				
				if(isSelected) {
					administrarFiltro(filtro);
				}
			}
		}
	}
	
	/**
	 * Metodo que recibe como parametro un filtro a administrar y un booleano que determina si 
	 * está seleccionado o no.
	 * Se supone que el filtro recibido y el boolean se corresponden.
	 * @param filtro
	 * @param isSelected
	 */
	private void administrarFiltro(FiltroArticulo filtro) {
		
		switch(filtro) {
		case TODO:
			
			habilitarFiltroTodo();
			break;
			
		case HAMBURGUESAS:
			
			habilitarFiltroHamburguesas();
			break;
			
		case BEBIDA:
			
			habilitarFiltroBebida();
			break;
			
		case COMPLEMENTO:
			
			habilitarFiltroComplemento();
			break;
			
		case POSTRE:
			
			habilitarFiltroPostre();
			break;
			
		default:
			throw new FilterNotFoundException("El filtro no pudo ser encontrado");
		}
	}

	private void habilitarFiltroPostre() {
		for(Articulo articulo:listaArticulos) {
			if(articulo.getTipo().equals("Postre")) {
				listaArticulosFiltrada.add(articulo);
			}
		}
	}

	private void habilitarFiltroComplemento() {
		for(Articulo articulo:listaArticulos) {
			if(articulo.getTipo().equals("Complemento")) {
				listaArticulosFiltrada.add(articulo);
			}
		}
	}

	private void habilitarFiltroBebida() {
		for(Articulo articulo:listaArticulos) {
			if(articulo.getTipo().equals("Bebida")) {
				listaArticulosFiltrada.add(articulo);
			}
		}
	}

	private void habilitarFiltroHamburguesas() {
		for(Articulo articulo:listaArticulos) {
			if(articulo.getTipo().equals("Hamburguesa")) {
				listaArticulosFiltrada.add(articulo);
			}
		}
	}

	private void habilitarFiltroTodo() {
		for(Articulo articulo:listaArticulos) {
			listaArticulosFiltrada.add(articulo);
		}
		
	}

}
