package uo.cpm.p3.console;

import uo.cpm.p3.console.interfaces.McDonaldsPresenter;
import uo.cpm.p3.model.Articulo;
import uo.cpm.p3.model.Cliente;
import uo.cpm.p3.util.check.ArgumentChecks;

/**
 * Clase que usa los metodos de la clase McDonaldsMenu
 * para preguntarle al cliente por inputs necesarios para la compra
 */
public class McDonaldsConsolePresenter implements McDonaldsPresenter {
	
	//Validaciones
	private boolean isValidMenuOption(char o) {
		return o == ORDER || o == QUIT;
	}
	
	private boolean isValidOrderOption(char o) {
		return o==REGISTER || o==CATALOG || o==ADD_ITEM || o==VIEW_PRICE || o==NEXT || o==BACK;
	}
	
	private boolean isValidString(String s) {
		ArgumentChecks.isNotNull(s);
		return !(s.isBlank()) || !s.isEmpty();
	}
	
	private boolean isValidAge(int i) {
		return i>=Cliente.EDAD_MIN && i<=Cliente.EDAD_MAX;
	}
	
	private boolean isValidUnits(int i) {
		return i>0;
	}
	
	@Override
	public char askMenuOption() {
		char option;
		do {
			option = McDonaldsMenu.readOption();
		}while(!isValidMenuOption(option));
		return option;
	}

	@Override
	public char askOrderOption() {
		char option;
		do {
			option = McDonaldsMenu.readOption();
		}while(!isValidOrderOption(option));
		return option;
	}

	@Override
	public String askClientName() {
		String clientName;
		do {
			clientName = McDonaldsMenu.readName();
		}while(!isValidString(clientName));
		return clientName;
	}

	@Override
	public int askBirthYear() {
		int birthYear;
		do {
			birthYear = McDonaldsMenu.readBirthYear();
		} while(!isValidAge(birthYear));
		return birthYear;
	}

	@Override
	public String askPassword() {
		String password;
		do {
			password = McDonaldsMenu.readPassword();
		} while(!isValidString(password));
		return password;
	}

	@Override
	public String confirmPassword() {
		String cpass;
		do {
			cpass = McDonaldsMenu.readPassword();
		} while(!isValidString(cpass));
		return cpass;
	}

	@Override
	public int askUnits() {
		int units;
		do {
			units= McDonaldsMenu.readUnits();
		} while(!isValidUnits(units));
		return units;
	}

	@Override
	public boolean askLocal() {
		boolean local;
		do {
			local = McDonaldsMenu.readLocal();
		} while(!local);
		return local;
	}

	@Override
	public Articulo askItem() {
		// TODO Auto-generated method stub
		return null;
	}

}
