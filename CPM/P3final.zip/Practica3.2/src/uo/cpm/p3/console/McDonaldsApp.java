package uo.cpm.p3.console;

public class McDonaldsApp {
	public void run() {
		
	}
}
