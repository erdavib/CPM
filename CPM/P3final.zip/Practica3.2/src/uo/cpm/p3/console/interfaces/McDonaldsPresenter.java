package uo.cpm.p3.console.interfaces;

import uo.cpm.p3.model.*;

/**
 * Interfaz que debe implementar toda clase que se encargue de mostrar por consola
 * mensajes que requieran la interaccion del usuario.
 */
public interface McDonaldsPresenter {
	//Menu options
	char ORDER = 'o';
	char QUIT = 'q';
	
	//Inside order
	char REGISTER = 'r';
	char CATALOG = 'c';
	char ADD_ITEM = 'a';
	char VIEW_PRICE = 'p';
	char NEXT = 'n';
	char BACK = 'b';
	
	//Yes/No Questions
	char YES = 'y';
	
	//Menu
	char askMenuOption();
	
	//Order
	char askOrderOption();
	
		//Register
		String askClientName();
		int askBirthYear();
		String askPassword();
		String confirmPassword();
	
		//Catalog (MessagePresenter)
	
		//Add item
		Articulo askItem();
		int askUnits();
	
		//View price (MessagePresenter)
	
	//Confirmation
	boolean askLocal();
}
