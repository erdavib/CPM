package uo.cpm.p3.console;

import uo.cpm.p3.util.console.Console;

public class McDonaldsMenu {
	
	public static char readOption() {
		return Character.toLowerCase(Console.readChar("Option"));
	}
	public static String readName() {
		return Console.readString("Name");
	}
	public static int readBirthYear() {
		return Console.readInt("Birth Year");
	}
	public static String readPassword() {
		return Console.readString("Enter password");
	}
	public static String confirmPassword() {
		return Console.readString("Confirm password");
	}
	public static int readUnits() {
		return Console.readInt("Units");
	}
	public static boolean readLocal() {
		String answer = Console.readString("For here or takeaway? (y/ yes for Local)");
		return answer.trim().toLowerCase().startsWith("y");
	}
	public static String readItem() {
		String answer = Console.readString("Select Item");
		return answer.trim().toLowerCase();
	}
}
