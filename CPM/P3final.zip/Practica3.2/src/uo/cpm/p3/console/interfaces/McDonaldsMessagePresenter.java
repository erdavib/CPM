package uo.cpm.p3.console.interfaces;

import uo.cpm.p3.model.Articulo;

/**
 * Interfaz que debe implementar toda clase que se encargue de mostrar por consola
 * mensajes que no requieran interaccion del usuario.
 */
public interface McDonaldsMessagePresenter {

	//Catalog
	void showCatalog(Articulo[] list);

	//View Price
	void showPrice(float f);
}
