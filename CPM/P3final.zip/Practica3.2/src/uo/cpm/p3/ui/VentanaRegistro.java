package uo.cpm.p3.ui;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import uo.cpm.p3.model.Pedido;
import uo.cpm.p3.service.McDonalds;
import uo.cpm.p3.util.check.ArgumentChecks;

public class VentanaRegistro extends JDialog {
	
	private static final long serialVersionUID = 1L;
	private McDonalds macdonalds;
	private JPanel pnPrincipal;
	private JPanel pnCliente;
	private JLabel lbNombre;
	private JTextField txNombre;
	private JLabel lbAnoNacimiento;
	private JLabel lbContrasena;
	private JLabel lbContrasena2;
	private JPasswordField pw1;
	private JPasswordField pw2;
	private JPanel pnPedido;
	private JButton btCancelar;
	private JButton btAceptar;
	private JRadioButton rbbtLocal;
	private JRadioButton rdbtLlevar;
	private final ButtonGroup bgPedido = new ButtonGroup();
	private JComboBox<String> cbAnos;

	/**
	 * Create the frame.
	 */
	public VentanaRegistro(McDonalds macdonalds) {
		ArgumentChecks.isNotNull(macdonalds);
		this.macdonalds=macdonalds;
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaRegistro.class.getResource("/img/logo.png")));
		setTitle("McDonalds: Datos del Registro");
		setBackground(new Color(255, 255, 255));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 600, 300);
		this.setLocationRelativeTo(null);
		pnPrincipal = new JPanel();
		pnPrincipal.setBackground(new Color(255, 255, 255));
		pnPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(pnPrincipal);
		pnPrincipal.setLayout(null);
		pnPrincipal.add(getPnCliente());
		pnPrincipal.add(getPnPedido());
		pnPrincipal.add(getBtCancelar());
		pnPrincipal.add(getBtAceptar());
		setLocationRelativeTo(null);
	}
	private JPanel getPnCliente() {
		if (pnCliente == null) {
			pnCliente = new JPanel();
			pnCliente.setBackground(new Color(255, 255, 255));
			pnCliente.setBorder(new TitledBorder(null, "Cliente", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			pnCliente.setBounds(10, 11, 564, 138);
			pnCliente.setLayout(null);
			pnCliente.add(getLbNombre());
			pnCliente.add(getTxNombre());
			pnCliente.add(getLbAnoNacimiento());
			pnCliente.add(getLbContrasena());
			pnCliente.add(getLbContrasena2());
			pnCliente.add(getPw1());
			pnCliente.add(getPw2());
			pnCliente.add(getCbAnos());
		}
		return pnCliente;
	}
	private JLabel getLbNombre() {
		if (lbNombre == null) {
			lbNombre = new JLabel("Nombre y Apellidos");
			lbNombre.setBounds(20, 28, 190, 14);
		}
		return lbNombre;
	}
	private JTextField getTxNombre() {
		if (txNombre == null) {
			txNombre = new JTextField();
			txNombre.setBounds(220, 25, 306, 20);
			txNombre.setColumns(10);
		}
		return txNombre;
	}
	private JLabel getLbAnoNacimiento() {
		if (lbAnoNacimiento == null) {
			lbAnoNacimiento = new JLabel("Ano de nacimiento");
			lbAnoNacimiento.setBounds(20, 53, 190, 14);
		}
		return lbAnoNacimiento;
	}
	private JLabel getLbContrasena() {
		if (lbContrasena == null) {
			lbContrasena = new JLabel("Contrasena");
			lbContrasena.setBounds(20, 78, 190, 14);
		}
		return lbContrasena;
	}
	private JLabel getLbContrasena2() {
		if (lbContrasena2 == null) {
			lbContrasena2 = new JLabel("Reintroduzca contrasena");
			lbContrasena2.setBounds(20, 103, 190, 14);
		}
		return lbContrasena2;
	}
	private JPasswordField getPw1() {
		if (pw1 == null) {
			pw1 = new JPasswordField();
			pw1.setBounds(220, 75, 306, 20);
		}
		return pw1;
	}
	private JPasswordField getPw2() {
		if (pw2 == null) {
			pw2 = new JPasswordField();
			pw2.setBounds(220, 100, 306, 20);
		}
		return pw2;
	}
	private JPanel getPnPedido() {
		if (pnPedido == null) {
			pnPedido = new JPanel();
			pnPedido.setBorder(new TitledBorder(null, "Pedido", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			pnPedido.setBackground(new Color(255, 255, 255));
			pnPedido.setBounds(10, 160, 270, 90);
			pnPedido.setLayout(null);
			pnPedido.add(getRbbtLocal());
			pnPedido.add(getRdbtLlevar());
		}
		return pnPedido;
	}
	private JButton getBtCancelar() {
		if (btCancelar == null) {
			btCancelar = new JButton("Cancelar");
			btCancelar.setForeground(new Color(255, 255, 255));
			btCancelar.setMnemonic('C');
			btCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btCancelar.setBackground(new Color(255, 0, 0));
			btCancelar.setBounds(485, 227, 89, 23);
		}
		return btCancelar;
	}
	private JButton getBtAceptar() {
		if (btAceptar == null) {
			btAceptar = new JButton("Siguiente");
			btAceptar.setMnemonic('S');
			btAceptar.setForeground(new Color(255, 255, 255));
			btAceptar.setBackground(new Color(0, 128, 64));
			btAceptar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					aniadirBolsa();
					avanzarPagina();
				}
			});
			btAceptar.setBounds(386, 227, 89, 23);
		}
		return btAceptar;
	}
	private void aniadirBolsa() {
		boolean tipoPedido = macdonalds.getTipoPedido();
		if(tipoPedido==Pedido.TIPO_LLEVAR) {
			macdonalds.aniadirBolsa();
		}
	}
	private void avanzarPagina() {
		if(validarFormulario()) {
			VentanaConfirmacion dialog = new VentanaConfirmacion(macdonalds);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		}
	}
	private boolean validarFormulario() {
		if(isVacioNombre()) {
			JOptionPane.showMessageDialog(this, "Debe introducir un valor para el nombre");
			return false;
		}
		if(isVacioContrasena() || isVacioRepetirContrasena()) {
			JOptionPane.showMessageDialog(this, "Debe introducir un valor para ambas contrase�as");
			return false;

		}
		if(isIncorrecta(pw1, pw2)) {
			JOptionPane.showMessageDialog(this, "Las contrasenias no coinciden");
			return false;

		}
		return true;
	}
	private boolean isVacioNombre() {
		return getTxNombre().getText().isBlank();
	}
	private boolean isVacioContrasena() {
		return pw1.getPassword().toString().isBlank();
	}
	private boolean isVacioRepetirContrasena() {
		return pw2.getPassword().toString().isBlank();
	}
	private boolean isIncorrecta(JPasswordField c1, JPasswordField c2) {
		String p1 = String.valueOf(c1.getPassword());
		String p2 = String.valueOf(c2.getPassword());
		
		return !(p1.equals(p2));
	}

	private JRadioButton getRbbtLocal() {
		if (rbbtLocal == null) {
			rbbtLocal = new JRadioButton("Local");
			rbbtLocal.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					actualizarTipoPedido(Pedido.TIPO_LOCAL);
				}
			});
			bgPedido.add(rbbtLocal);
			rbbtLocal.setSelected(true);
			rbbtLocal.setBackground(new Color(255, 255, 255));
			rbbtLocal.setBounds(18, 38, 109, 23);
		}
		return rbbtLocal;
	}
	private JRadioButton getRdbtLlevar() {
		if (rdbtLlevar == null) {
			rdbtLlevar = new JRadioButton("Llevar");
			rdbtLlevar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					actualizarTipoPedido(Pedido.TIPO_LLEVAR);
				}
			});
			bgPedido.add(rdbtLlevar);
			rdbtLlevar.setBackground(new Color(255, 255, 255));
			rdbtLlevar.setBounds(129, 38, 118, 23);
		}
		return rdbtLlevar;
	}
	
	private void actualizarTipoPedido(boolean local) {
		macdonalds.actualizarTipoPedido(local);
	}
	private JComboBox<String> getCbAnos() {
		if (cbAnos == null) {
			cbAnos = new JComboBox<String>();
			cbAnos.setModel(new DefaultComboBoxModel<String>(macdonalds.getRangoAnios()));
			cbAnos.setBounds(220, 49, 117, 22);
		}
		return cbAnos;
	}
}
