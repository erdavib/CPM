package uo.cpm.p3.ui;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;

import uo.cpm.p3.model.Articulo;
import uo.cpm.p3.service.McDonalds;
import uo.cpm.p3.util.check.ArgumentChecks;

public class VentanaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private McDonalds mcDonalds;
	private JPanel contentPane;
	private JComboBox<Articulo> cbArticulo;
	private JLabel lbArticulo;
	private JLabel lbLogo;
	private JLabel lbMcDonalds;
	private JSpinner spUnidades;
	private JLabel lbUnidadesProducto;
	private JButton btnAñadir;
	private JLabel lbPrecioPedido;
	private JButton btnCancelar;
	private JButton btnSiguiente;
	private JTextField txtPrecio;
	private JLabel lbUnidades;

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal(McDonalds mcDonalds) {
		ArgumentChecks.isNotNull(mcDonalds);

		this.mcDonalds = mcDonalds;
		setTitle("McDonalds: Ventana Principal");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/logo.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 645, 465);
		this.setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getCbArticulo());
		contentPane.add(getLbArticulo());
		contentPane.add(getLbLogo());
		contentPane.add(getLbMcDonalds());
		contentPane.add(getSpUnidades());
		contentPane.add(getLbUnidadesProducto());
		contentPane.add(getBtnAñadir());
		contentPane.add(getLbPrecioPedido());
		contentPane.add(getBtnCancelar());
		contentPane.add(getBtnSiguiente());
		contentPane.add(getTxtPrecio());
		contentPane.add(getLbUnidades());

	}

	private JComboBox<Articulo> getCbArticulo() {
		if (cbArticulo == null) {
			cbArticulo = new JComboBox<Articulo>();
			cbArticulo.setModel(new DefaultComboBoxModel<Articulo>(mcDonalds.getArticulosCarta()));
			cbArticulo.setBounds(37, 196, 348, 22);
		}
		return cbArticulo;
	}
	private JLabel getLbArticulo() {
		if (lbArticulo == null) {
			lbArticulo = new JLabel("Articulo");
			lbArticulo.setFont(new Font("Tahoma", Font.PLAIN, 11));
			lbArticulo.setBounds(37, 174, 87, 22);
		}
		return lbArticulo;
	}
	private JLabel getLbLogo() {
		if (lbLogo == null) {
			lbLogo = new JLabel("");
			lbLogo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/logo.png")));
			lbLogo.setBounds(37, 11, 156, 152);
		}
		return lbLogo;
	}
	private JLabel getLbMcDonalds() {
		if (lbMcDonalds == null) {
			lbMcDonalds = new JLabel("McDonald`s");
			lbMcDonalds.setFont(new Font("Arial Black", Font.PLAIN, 44));
			lbMcDonalds.setBounds(226, 80, 303, 46);
		}
		return lbMcDonalds;
	}
	private JSpinner getSpUnidades() {
		if (spUnidades == null) {
			spUnidades = new JSpinner();
			spUnidades.setModel(new SpinnerNumberModel(Integer.valueOf(1), Integer.valueOf(1), null, Integer.valueOf(1)));
			spUnidades.setBounds(395, 197, 40, 20);
		}
		return spUnidades;
	}
	private JLabel getLbUnidadesProducto() {
		if (lbUnidadesProducto == null) {
			lbUnidadesProducto = new JLabel("Unidades");
			lbUnidadesProducto.setBounds(395, 178, 46, 14);
		}
		return lbUnidadesProducto;
	}
	private JButton getBtnAñadir() {
		if (btnAñadir == null) {
			btnAñadir = new JButton("A\u00F1adir");
			btnAñadir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					aniadirAPedido();
					aniadirMostrar();
				}
			});
			btnAñadir.setBackground(new Color(0, 128, 0));
			btnAñadir.setForeground(new Color(255, 255, 255));
			btnAñadir.setBounds(445, 196, 89, 23);
		}
		return btnAñadir;
	}
	
	private void aniadirMostrar() {
		lbUnidades = getLbUnidades();
		
		Articulo articuloSeleccionado = (Articulo) getCbArticulo().getSelectedItem();
		Articulo articuloListado = mcDonalds.getArticuloListado(articuloSeleccionado);
		int unidades = articuloListado.getUnidades();
		String text = String.format("El numero de unidades del articulo ahora es: %d", unidades);
		
		lbUnidades.setText(text);;
		
	}
	
	private void aniadirAPedido() {
		Articulo articuloSeleccionado = (Articulo) getCbArticulo().getSelectedItem();
		int unidadesSolicitadas = (int) getSpUnidades().getValue();
		mcDonalds.aniadirAPedido(articuloSeleccionado, unidadesSolicitadas);
		String precio = String.format("%.2f", mcDonalds.getImportePedido());
		getTxtPrecio().setText(precio + " €");
		if (!getBtnSiguiente().isEnabled()) {
			getBtnSiguiente().setEnabled(true);
		}
		
	}
	private JLabel getLbPrecioPedido() {
		if (lbPrecioPedido == null) {
			lbPrecioPedido = new JLabel("Precio pedido");
			lbPrecioPedido.setBounds(395, 228, 74, 14);
		}
		return lbPrecioPedido;
	}
	private JButton getBtnCancelar() {
		if (btnCancelar == null) {
			btnCancelar = new JButton("Cancelar");
			btnCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			btnCancelar.setForeground(new Color(255, 255, 255));
			btnCancelar.setBackground(new Color(255, 0, 0));
			btnCancelar.setBounds(530, 392, 89, 23);
		}
		return btnCancelar;
	}
	private JButton getBtnSiguiente() {
		if (btnSiguiente == null) {
			btnSiguiente = new JButton("Siguiente");
			btnSiguiente.setEnabled(false);
			btnSiguiente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					VentanaRegistro frame = new VentanaRegistro(mcDonalds);
					frame.setVisible(true);
				}
			});
			btnSiguiente.setForeground(new Color(255, 255, 255));
			btnSiguiente.setBackground(new Color(0, 128, 0));
			btnSiguiente.setBounds(431, 392, 89, 23);
		}
		return btnSiguiente;
	}
	private JTextField getTxtPrecio() {
		if (txtPrecio == null) {
			txtPrecio = new JTextField();
			txtPrecio.setFocusable(false);
			txtPrecio.setEditable(false);
			txtPrecio.setBounds(395, 259, 74, 20);
			txtPrecio.setColumns(10);
		}
		return txtPrecio;
	}
	private JLabel getLbUnidades() {
		if (lbUnidades == null) {
			lbUnidades = new JLabel("");
			lbUnidades.setFont(new Font("Arial Black", Font.PLAIN, 12));
			lbUnidades.setForeground(new Color(255, 0, 0));
			lbUnidades.setBounds(37, 262, 348, 14);
		}
		return lbUnidades;
	}
}
