package uo.cpm.p3.exceptions;

/**
 * Excepcion que debe lanzarse si no se encuentra un Articulo en un pedido
 */
public class ItemNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	private String message;
	
	public ItemNotFoundException() {
		
	}
	
	public ItemNotFoundException(String message) {
		if(message!=null) {
			this.message=message;
		}
	}
	
	public String getMessage() {
		return message;
	}

}
