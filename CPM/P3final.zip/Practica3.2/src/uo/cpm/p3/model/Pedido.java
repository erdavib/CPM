package uo.cpm.p3.model;

import java.util.*;

import uo.cpm.p3.service.McDonalds;
import uo.cpm.p3.util.FileUtil;

/**
 * Clase que se encarga de almacenar todos los datos de un pedido
 */
public class Pedido {

	/**
	 * Tipo asociado a un pedido para consumir en el local
	 */
	public static final boolean TIPO_LOCAL = true;
	/**
	 * Tipo asociado a un pedido para llevar
	 */
	public static final boolean TIPO_LLEVAR = false;
	/**
	 * Longitud que tiene un codigo de un pedido por defecto
	 */
	public static final int LONGITUD_CODIGO = 8;

	private List<Articulo> listaPedido;
	private String codigo;
	private float importe;
	private boolean local;
	private Cliente cliente;

	public Pedido() {
		listaPedido = new ArrayList<Articulo>();
		inicializar();
	}

	/**
	 * Genera un codigo aleatorio para el pedido, por defecto el importe es 0, el
	 * pedido es para consumir en el local, y el cliente inexistente. Inicializa la
	 * lista de articulos vacía
	 */
	public void inicializar() {
		listaPedido.clear();
		generarCodigo();
		setImporte(0);
		setLocal(TIPO_LOCAL);
		setCliente(null);
	}

	/**
	 * Agrega al pedido un numero de unidades de un articulo.
	 * Calcula el importe total del pedido de nuevo cada vez que se agrega un articulo
	 * @param articuloDelCatalogo Articulo a añadir
	 * @param unidades            Unidades a añadir
	 */
	public void add(Articulo articuloDelCatalogo, int unidades) {
		Articulo articuloEnPedido = null;

		for (Articulo a : listaPedido) {
			if (a.getCodigo().equals(articuloDelCatalogo.getCodigo())) {
				articuloEnPedido = a;
				articuloEnPedido.setUnidades(articuloEnPedido.getUnidades() + unidades);
				break;
			}
		}

		if (articuloEnPedido == null) {
			articuloEnPedido = new Articulo(articuloDelCatalogo);
			articuloEnPedido.setUnidades(unidades);
			listaPedido.add(articuloEnPedido);
		}
		calcularImporte();
	}

	/**
	 * Agrega el precio de la bolsa al pedido si el pedido es para llevar
	 */
	public void aniadirBolsa() {
		if (isLocal() == TIPO_LLEVAR) {
			float precioBolsa = McDonalds.PRECIO_BOLSA;
			float precioFinal = getImporte() + precioBolsa;
			setImporte(precioFinal);
		}
	}

	/**
	 * Calcula el importe total del pedido
	 */
	private void calcularImporte() {
		importe = 0;
		for (Articulo a : listaPedido)
			importe += a.getPrecio() * a.getUnidades();
	}

	/**
	 * Guarda el pedido en un fichero
	 */
	public void grabarPedido() {
		FileUtil.saveToFile(this);
	}

	/**
	 * Devuelve una copia de la lista de pedidos que se tiene por atributo
	 * @return ArrayList Descrito
	 */
	public List<Articulo> getListaPedido() {
		return new ArrayList<Articulo>(listaPedido);
	}

	public void setListaPedido(List<Articulo> listaPedido) {
		this.listaPedido = listaPedido;
	}

	public String getCodigo() {
		return codigo;
	}

	public float getImporte() {
		return importe;
	}

	public void setImporte(float importe) {
		this.importe = importe;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public void setLocal(boolean tipo) {
		local = tipo;
		
	}

	public boolean isLocal() {
		return local;
	}

	/**
	 * Genera un codigo aleatorio para el pedido de longitud establecida por la constante asociada LONGITUD_CODIGO
	 */
	public void generarCodigo() {
		codigo = "";// Se inicializa el código como cadena vacía
		String base = "0123456789abcdefghijklmnopqrstuvwxyz";
		int longitudCodigo = LONGITUD_CODIGO;
		for (int i = 0; i < longitudCodigo; i++) // (Sería mejor usar un stringBuilder
			// Se elige un índice aleatorio dentro de la base
			codigo += base.charAt((int) (Math.random() * (base.length())));
		// Se agrega el carácter elegido al código
	}

}
