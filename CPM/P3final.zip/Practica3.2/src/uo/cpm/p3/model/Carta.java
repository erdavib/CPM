package uo.cpm.p3.model;

import java.util.*;

import uo.cpm.p3.util.FileUtil;

/**
 * Clase encargada de cargar y devolver la lista de articulos disponibles, que se encuentra en un fichero
 */
public class Carta {

	/**
	 * Fichero en el que se encuentran por defecto los articulos a cargar
	 */
	private static final String FICHERO_ARTICULOS = "files/articulos.dat";
	private List<Articulo> listaArticulos = null;

	public Carta() {
		listaArticulos = new ArrayList<Articulo>();
		cargarArticulos();
	}

	private void cargarArticulos() {
		FileUtil.loadFile(FICHERO_ARTICULOS, listaArticulos);
	}

	/**
	 * @return Articulo[] Copia del array que se tiene como atributo
	 */
	public Articulo[] getArticulos() {
		Articulo[] articulos = listaArticulos.toArray(new Articulo[listaArticulos.size()]);
		return articulos;
	}

}
