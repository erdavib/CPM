package uo.cpm.p8.player;

import java.io.File;
import java.util.*;

import javazoom.jlgui.basicplayer.*;

public class MusicPlayer {
	public static final double VOLUME_MAX = 100;
	public static final double VOLUME_MIN = 0;

	private BasicPlayer basicPlayer = null;
	private List<File> listLibrary = null;
	private List<File> listPlay = null;
	private File currentSong; // representa la cancion que está seleccionada en el ListPlay
	private int volume = 0; // representa el volumen actual

	public MusicPlayer() {
		basicPlayer = new BasicPlayer();
		listLibrary = new ArrayList<File>();
		listPlay = new ArrayList<File>();
		currentSong = null;
		volume = 50;
	}

	public List<File> getListLibrary() {
		return listLibrary;
	}

	public List<File> getListPlay() {
		return listPlay;
	}

	public File getCurrentSong() {
		return currentSong;
	}

	public void setCurrentSong(File f) {
		this.currentSong = f;
	}

	public int getVolume() {
		return volume;
	}

	public void addListLibrary(File[] selectedFiles) {

	}

	public void addListPlay(List<File> selectedValuesList) {

	}

	public void deleteListLibrary(List<File> selectedValuesList) {

	}

	public void rewind() {

	}

	public void forward() {

	}

	public int searchFilePosition() {

		return -1;
	}

	public void deleteListPlay(File selectedValue) {

	}

	/**********************************************
	 * REPRODUCTOR *
	 **********************************************/

	public void play() {
		try {
			basicPlayer.open(currentSong);
			basicPlayer.play();
			setVolume(volume);
		} catch (BasicPlayerException e) {
			System.out.println("Error en play");
		}
	}

	public void stop() {
		try {
			basicPlayer.stop();
		} catch (BasicPlayerException e) {
			System.out.println("Error en stop");
		}
	}

	public void setVolume(int vol) {
		try {
			this.volume = vol;
			if (basicPlayer.getStatus() == BasicPlayer.PLAYING)
				basicPlayer.setGain(vol / VOLUME_MAX);
		} catch (BasicPlayerException e) {
			System.out.println("Error en volumen");
		}
	}
}
