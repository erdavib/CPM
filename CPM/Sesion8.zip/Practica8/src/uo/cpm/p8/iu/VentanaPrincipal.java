package uo.cpm.p8.iu;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaPrincipal extends JFrame{
	public VentanaPrincipal() {
		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				System.out.println(((Component) e.getSource()).getSize());
			}
		});
		getContentPane().setBackground(Color.LIGHT_GRAY);
		getContentPane().setLayout(new BorderLayout(0, 0));
		getContentPane().add(getPnNorte(), BorderLayout.NORTH);
		getContentPane().add(getPnCentro(), BorderLayout.CENTER);
		setTitle("EII Los duros MUSIC PLAYER");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/logoTitulo.png")));
		setBounds(0,0,670,500);
		setLocationRelativeTo(null);
		setJMenuBar(getMenuBar_1());
		this.setMinimumSize(new Dimension(550, 225));
	}

	private static final long serialVersionUID = 1L;
	private JMenuBar mnBar;
	private JMenu mnMenu;
	private JFileChooser selector;
	private JMenu mnOptions;
	private JMenu mnHelp;
	private JMenuItem miAbout;
	private JMenuItem miExit;
	private JSeparator separator;
	private JSeparator separator_1;
	private JPanel pnNorte;
	private JLabel lbLogo;
	private JSlider slVolumen;
	private JPanel pnVolumen;
	private JLabel lbVol;
	private JLabel lbVolValue;
	private JPanel pnCentro;
	private JPanel pnLibreria;
	private JPanel pnPlaylist;
	private JLabel lbLibreria;
	private JPanel pnBotonesLibreria;
	private JButton btAddToPlaylist;
	private JButton btDelLibreria;
	private JScrollPane spnLibreria;
	private JList<File> listLibreria;
	private JLabel lbPlaylist;
	private JScrollPane spnPlaylist;
	private JList<File> listPlaylist;
	private JPanel pnBotonesPlaylist;
	private JButton btBack;
	private JButton btPlay;
	private JButton btStop;
	private JButton btForward;
	private JButton btDelPlaylist;
	private JMenuItem miContents;
	private JMenuItem miOpen;
	private JMenuItem miRandom;

	private JMenuBar getMenuBar_1() {
		if (mnBar == null) {
			mnBar = new JMenuBar();
			mnBar.add(getMnMenu());
			mnBar.add(getMnOptions());
			mnBar.add(getMnHelp());
		}
		return mnBar;
	}
	private JMenu getMnMenu() {
		if (mnMenu == null) {
			mnMenu = new JMenu("Menu");
			mnMenu.setMnemonic('m');
			mnMenu.add(getMiOpen());
			mnMenu.add(getSeparator());
			mnMenu.add(getMiExit());
		}
		return mnMenu;
	}
	private JMenu getMnOptions() {
		if (mnOptions == null) {
			mnOptions = new JMenu("Options");
			mnOptions.setMnemonic('o');
			mnOptions.add(getMiRandom());
		}
		return mnOptions;
	}
	private JMenu getMnHelp() {
		if (mnHelp == null) {
			mnHelp = new JMenu("Help");
			mnHelp.setMnemonic('h');
			mnHelp.add(getMiContents());
			mnHelp.add(getSeparator_1());
			mnHelp.add(getMiAbout());
		}
		return mnHelp;
	}
	private JMenuItem getMiAbout() {
		if (miAbout == null) {
			miAbout = new JMenuItem("About");
			miAbout.setMnemonic('a');
		}
		return miAbout;
	}
	private JMenuItem getMiExit() {
		if (miExit == null) {
			miExit = new JMenuItem("Exit");
			miExit.setMnemonic('e');
		}
		return miExit;
	}
	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}
	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}
	private JPanel getPnNorte() {
		if (pnNorte == null) {
			pnNorte = new JPanel();
			pnNorte.setBackground(Color.BLACK);
			pnNorte.setLayout(new GridLayout(1, 3, 0, 0));
			pnNorte.add(getLbLogo());
			pnNorte.add(getSlVolumen());
			pnNorte.add(getPnVolumen());
		}
		return pnNorte;
	}
	private JLabel getLbLogo() {
		if (lbLogo == null) {
			lbLogo = new JLabel("");
			lbLogo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/logo.png")));
		}
		return lbLogo;
	}
	private JSlider getSlVolumen() {
		if (slVolumen == null) {
			slVolumen = new JSlider();
			slVolumen.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					pintaYCambiaVol();
				}
			});
			slVolumen.setForeground(new Color(252, 197, 242));
			slVolumen.setFont(new Font("Tahoma", Font.PLAIN, 14));
			slVolumen.setPaintLabels(true);
			slVolumen.setPaintTicks(true);
			slVolumen.setMinorTickSpacing(5);
			slVolumen.setMajorTickSpacing(20);
			slVolumen.setValue(0);
			slVolumen.setBackground(Color.BLACK);
		}
		return slVolumen;
	}
	private JPanel getPnVolumen() {
		if (pnVolumen == null) {
			pnVolumen = new JPanel();
			pnVolumen.setBackground(Color.BLACK);
			pnVolumen.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			pnVolumen.add(getLbVol());
			pnVolumen.add(getLbVolValue());
		}
		return pnVolumen;
	}
	private JLabel getLbVol() {
		if (lbVol == null) {
			lbVol = new JLabel("Vol:");
			lbVol.setHorizontalAlignment(SwingConstants.CENTER);
			lbVol.setFont(new Font("Tahoma", Font.PLAIN, 26));
			lbVol.setForeground(new Color(252, 197, 242));
		}
		return lbVol;
	}
	private JLabel getLbVolValue() {
		if (lbVolValue == null) {
			lbVolValue = new JLabel("0");
			lbVolValue.setFont(new Font("Tahoma", Font.PLAIN, 26));
			lbVolValue.setForeground(Color.WHITE);
			lbVolValue.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lbVolValue;
	}
	
	private void pintaYCambiaVol() {
		getLbVolValue().setText(String.valueOf(getSlVolumen().getValue()));
	}
	private JPanel getPnCentro() {
		if (pnCentro == null) {
			pnCentro = new JPanel();
			pnCentro.setBackground(Color.BLACK);
			pnCentro.setLayout(new GridLayout(1, 2, 5, 0));
			pnCentro.add(getPnLibreria());
			pnCentro.add(getPnPlaylist());
		}
		return pnCentro;
	}
	private JPanel getPnLibreria() {
		if (pnLibreria == null) {
			pnLibreria = new JPanel();
			pnLibreria.setBackground(Color.BLACK);
			pnLibreria.setLayout(new BorderLayout(0, 0));
			pnLibreria.add(getLbLibreria(), BorderLayout.NORTH);
			pnLibreria.add(getPnBotonesLibreria(), BorderLayout.SOUTH);
			pnLibreria.add(getSpnLibreria(), BorderLayout.CENTER);
		}
		return pnLibreria;
	}
	private JPanel getPnPlaylist() {
		if (pnPlaylist == null) {
			pnPlaylist = new JPanel();
			pnPlaylist.setBackground(Color.BLACK);
			pnPlaylist.setLayout(new BorderLayout(0, 0));
			pnPlaylist.add(getLbPlaylist(), BorderLayout.NORTH);
			pnPlaylist.add(getSpnPlaylist(), BorderLayout.CENTER);
			pnPlaylist.add(getPnBotonesPlaylist(), BorderLayout.SOUTH);
		}
		return pnPlaylist;
	}
	private JLabel getLbLibreria() {
		if (lbLibreria == null) {
			lbLibreria = new JLabel("Library");
			lbLibreria.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lbLibreria.setForeground(new Color(252, 197, 242));
			lbLibreria.setBackground(Color.BLACK);
		}
		return lbLibreria;
	}
	private JPanel getPnBotonesLibreria() {
		if (pnBotonesLibreria == null) {
			pnBotonesLibreria = new JPanel();
			pnBotonesLibreria.setLayout(new GridLayout(1, 2, 2, 0));
			pnBotonesLibreria.add(getBtAddToPlaylist());
			pnBotonesLibreria.add(getBtDelLibreria());
		}
		return pnBotonesLibreria;
	}
	private JButton getBtAddToPlaylist() {
		if (btAddToPlaylist == null) {
			btAddToPlaylist = new JButton("Add to playlist");
			btAddToPlaylist.setMargin(new Insets(0, 0, 0, 0));
			btAddToPlaylist.setFont(new Font("Arial", Font.BOLD, 16));
		}
		return btAddToPlaylist;
	}
	private JButton getBtDelLibreria() {
		if (btDelLibreria == null) {
			btDelLibreria = new JButton("Del");
			btDelLibreria.setMargin(new Insets(0, 0, 0, 0));
			btDelLibreria.setFont(new Font("Arial", Font.BOLD, 16));
		}
		return btDelLibreria;
	}
	private JScrollPane getSpnLibreria() {
		if (spnLibreria == null) {
			spnLibreria = new JScrollPane();
			spnLibreria.setForeground(Color.BLACK);
			spnLibreria.setBackground(new Color(0, 0, 0));
			spnLibreria.setBorder(new LineBorder(new Color(255, 187, 243), 3, true));
			spnLibreria.setViewportView(getListLibreria());
		}
		return spnLibreria;
	}
	private JList<File> getListLibreria() {
		if (listLibreria == null) {
			listLibreria = new JList<File>();
			listLibreria.setFont(new Font("Tahoma", Font.PLAIN, 14));
			listLibreria.setForeground(new Color(255, 255, 255));
			listLibreria.setBackground(new Color(0, 0, 0));
		}
		return listLibreria;
	}
	private JLabel getLbPlaylist() {
		if (lbPlaylist == null) {
			lbPlaylist = new JLabel("Playlist");
			lbPlaylist.setForeground(new Color(252, 197, 242));
			lbPlaylist.setFont(new Font("Tahoma", Font.PLAIN, 15));
		}
		return lbPlaylist;
	}
	private JScrollPane getSpnPlaylist() {
		if (spnPlaylist == null) {
			spnPlaylist = new JScrollPane();
			spnPlaylist.setBorder(new LineBorder(new Color(252, 197, 242), 3, true));
			spnPlaylist.setViewportView(getListPlaylist());
		}
		return spnPlaylist;
	}
	private JList<File> getListPlaylist() {
		if (listPlaylist == null) {
			listPlaylist = new JList<File>();
			listPlaylist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			listPlaylist.setForeground(new Color(255, 255, 255));
			listPlaylist.setBackground(new Color(0, 0, 0));
		}
		return listPlaylist;
	}
	private JPanel getPnBotonesPlaylist() {
		if (pnBotonesPlaylist == null) {
			pnBotonesPlaylist = new JPanel();
			pnBotonesPlaylist.setLayout(new GridLayout(1, 5, 2, 0));
			pnBotonesPlaylist.add(getBtBack());
			pnBotonesPlaylist.add(getBtPlay());
			pnBotonesPlaylist.add(getBtStop());
			pnBotonesPlaylist.add(getBtForward());
			pnBotonesPlaylist.add(getBtDelPlaylist());
		}
		return pnBotonesPlaylist;
	}
	private JButton getBtBack() {
		if (btBack == null) {
			btBack = new JButton("◄◄");
			btBack.setMargin(new Insets(0, 0, 0, 0));
			btBack.setFont(new Font("Arial", Font.BOLD, 16));
		}
		return btBack;
	}
	private JButton getBtPlay() {
		if (btPlay == null) {
			btPlay = new JButton("►");
			btPlay.setMargin(new Insets(0, 0, 0, 0));
			btPlay.setFont(new Font("Arial", Font.BOLD, 16));
		}
		return btPlay;
	}
	private JButton getBtStop() {
		if (btStop == null) {
			btStop = new JButton("■");
			btStop.setMargin(new Insets(0, 0, 0, 0));
			btStop.setFont(new Font("Dialog", Font.BOLD, 16));
		}
		return btStop;
	}
	private JButton getBtForward() {
		if (btForward == null) {
			btForward = new JButton("►►");
			btForward.setMargin(new Insets(0, 0, 0, 0));
			btForward.setFont(new Font("Arial", Font.BOLD, 16));
		}
		return btForward;
	}
	private JButton getBtDelPlaylist() {
		if (btDelPlaylist == null) {
			btDelPlaylist = new JButton("Del");
			btDelPlaylist.setMargin(new Insets(0, 0, 0, 0));
			btDelPlaylist.setFont(new Font("Arial", Font.BOLD, 16));
		}
		return btDelPlaylist;
	}
	private JMenuItem getMiContents() {
		if (miContents == null) {
			miContents = new JMenuItem("Contents");
			miContents.setMnemonic('c');
		}
		return miContents;
	}
	private JMenuItem getMiOpen() {
		if (miOpen == null) {
			miOpen = new JMenuItem("Open");
			miOpen.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					getSelector();
				}
			});
			miOpen.setMnemonic('o');
		}
		return miOpen;
	}
	
	private JFileChooser getSelector() {
		if(selector==null) {
			selector = new JFileChooser();
			selector.setMultiSelectionEnabled(true);
		}
		return selector;
	}
	private JMenuItem getMiRandom() {
		if (miRandom == null) {
			miRandom = new JMenuItem("Random");
			miRandom.setMnemonic('r');
		}
		return miRandom;
	}
}
