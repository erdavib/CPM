package uo.cpm.p7.service;

import uo.cpm.p7.game.Juego;
import uo.cpm.p7.model.Tablero;
import uo.cpm.p7.model.Casilla.TipoCasilla;
import uo.cpm.p7.model.Nivel;

public class SpaceInvaders {
	
	public final static Nivel DEFAULT_DIFFICULTY = Nivel.INTERMEDIO;
	private Juego juego = new Juego();

	public Tablero getTablero()
	{
		return juego.getTablero();
	}

	public void inicializar(Nivel nivel)
	{
		if(nivel!=null) {

			juego.inicializarJuego(nivel);
		}else {
			juego.inicializarJuego(DEFAULT_DIFFICULTY);
		}
	}

	public void dipara(int i)
	{
		juego.dispara(i);
	}

	public boolean isFinJuego()
	{
		return juego.isFinJuego();
	}
	
	public int getPuntuacion()
	{
		return juego.getPuntos();
	}

	public void lanzarDado()
	{
		juego.lanzar();
	}

	public int getDisparos()
	{
		return juego.getDisparos();
	}

	public String obtenerImagen(int i) 
	{
		return juego.obtenerImagen(i);
	}

	public String getMotivoFin() {
		if (!juego.getCasillaDisparada().getTipoCasilla().equals(TipoCasilla.NEUTRO)) {
			return "Partida finalizada: " + juego.getCasillaDisparada().getNombre() + " encontrado";
		}else {
			return "Partida finalizada: disparos agotados";
		}
	}

	public int getDimension() {
		return Tablero.DIM;
	}

	
	
}