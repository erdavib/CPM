package uo.cpm.p7.model;

import uo.cpm.p7.model.Casilla.TipoCasilla;

public class Tablero {
	
	public static final int DIM = 8;
	Casilla[] casillas;
	private int dim;
	private int nInvasores;
	private int nMeteoritos;
	
	public Tablero(Nivel nivel) {
		this.dim = nivel.getNumCasillas();
		this.nInvasores = nivel.getNumInvasores();
		this.nMeteoritos = nivel.getNumMeteoritos();
		casillas = new Casilla[dim];
		for (int i=0;i<dim;i++) {
			casillas[i] = new Casilla ("Espacio",TipoCasilla.NEUTRO,-200,"/img/space.jpg");
			
		}
		colocaInvasor();
		colocaMeteorito();
	}

	private void colocaInvasor() {
		for(int i=0;i<nInvasores;i++) {
			int posicionInvasor;
			do {
				posicionInvasor = (int) (Math.random() * dim);
			} while(!casillas[posicionInvasor].getTipoCasilla().equals(TipoCasilla.NEUTRO));
			casillas[posicionInvasor] = new  Casilla ("Invasor",TipoCasilla.ENEMIGO,3000,"/img/invader.jpg");
			System.out.println("Posici�n invasor = "+posicionInvasor);
		}
		
	}
	
	private void colocaMeteorito() {
		for(int i=0;i<nMeteoritos;i++) {
			int posicionMeteorito;
			do {
				posicionMeteorito = (int) (Math.random() * dim);
			}while(!casillas[posicionMeteorito].getTipoCasilla().equals(TipoCasilla.NEUTRO));
			casillas[posicionMeteorito] = new Casilla("Meteorito", TipoCasilla.METEORITO, 0, "/img/meteorite.jpg");
			System.out.println("Posici�n meteorito = "+ posicionMeteorito);
		}
	}
	
	
	public Casilla[] getCasillas() {
		return casillas;
	}
	
	public String obtenerImagen(int i) {
		return casillas[i].getImagen();
	}
}
