package uo.cpm.p7.ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import uo.cpm.p7.model.Nivel;
import uo.cpm.p7.service.SpaceInvaders;

import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ButtonGroup;

public class VentanaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;

	private SpaceInvaders spaceInvaders;

	private JPanel contentPane;
	private JButton btnDado;
	private JPanel pnDisparos;
	private JPanel pnTablero;
	private JLabel lblPlaneta;
	private JLabel lblScore;
	private JTextField TxPuntos;
	private JLabel lblNave;
	private JMenuBar menuBar;
	private JMenu mnJuego;
	private JMenu mnAyuda;
	private JMenuItem mntmNuevo;
	private JMenuItem mntmSalir;
	private JMenuItem mntmAcercaDe;
	private ProcesaBotonTablero pbt = new ProcesaBotonTablero();
	private ProcesaBotonNivel pbn = new ProcesaBotonNivel();
	private JMenu mnNiveles;
	private JRadioButtonMenuItem rbmFacil;
	private JRadioButtonMenuItem rbmIntermedio;
	private JRadioButtonMenuItem rbmDificil;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal(SpaceInvaders spaceInvaders) {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				confirmarSalir();
			}
		});
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/spaceship.png")));

		this.spaceInvaders = spaceInvaders;

		setResizable(false);
		setTitle("Space");

		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 1080, 400);
		setLocationRelativeTo(null);
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getBtnDado());
		contentPane.add(getPnDisparos());
		contentPane.add(getPnTablero());
		contentPane.add(getLblPlaneta());
		contentPane.add(getLblScore());
		contentPane.add(getTxPuntos());
		contentPane.add(getLblNave());
	}

	public class ProcesaBotonTablero implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			int indice = Integer.parseInt(e.getActionCommand());
			
			dispara(indice);
		}
		
	}
	
	public class ProcesaBotonNivel implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			switch(e.getActionCommand()) {
			case("facil"):
				inicializar(Nivel.FACIL);
				break;
			case("intermedio"):
				inicializar(Nivel.INTERMEDIO);
				break;
			case("dificil"):
				inicializar(Nivel.DIFICIL);
				break;
			}
		}
	}
	
	private JButton getBtnDado() {
		if (btnDado == null) {
			btnDado = new JButton("");
			btnDado.setFocusable(false);
			btnDado.setDisabledIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/dice.jpg")));
			btnDado.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					iniciarSpaceInvaders();
				}
			});
			btnDado.setFocusPainted(false);
			btnDado.setBackground(Color.BLACK);
			btnDado.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/dice.jpg")));
			btnDado.setToolTipText("Pulsa para obtener n\u00FAmero de disparos");
			btnDado.setBounds(20, 27, 109, 109);
		}
		return btnDado;
	}

	private void iniciarSpaceInvaders() {
		spaceInvaders.lanzarDado();
		pintaDisparos();
		getBtnDado().setEnabled(false);
		habilitaTablero(true);
	}

	private void pintaDisparos() {
		for (int i = 0; i < spaceInvaders.getDisparos(); i++) {
			getPnDisparos().add(nuevoDisparo());
		}
		validate(); // Obliga a repintarse al panel para mostrar los disparos
	}

	private Component nuevoDisparo() {
		JLabel lbDisparo = new JLabel("");
		lbDisparo.setBorder(new LineBorder(Color.GREEN, 2));
		lbDisparo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/shoot.png")));
		return lbDisparo;

	}

	private JPanel getPnDisparos() {
		if (pnDisparos == null) {
			pnDisparos = new JPanel();
			pnDisparos.setBackground(Color.BLACK);
			pnDisparos.setBounds(197, 124, 603, 78);
		}
		return pnDisparos;
	}

	private JPanel getPnTablero() {
		if (pnTablero == null) {
			pnTablero = new JPanel();
			pnTablero.setBorder(new LineBorder(Color.BLUE, 5));
			pnTablero.setBackground(Color.BLUE);
			pnTablero.setBounds(20, 233, 1034, 95);
			pnTablero.setLayout(new GridLayout(1, 8, 4, 0));
			redimensionarTablero(SpaceInvaders.DEFAULT_DIFFICULTY);
			habilitaTablero(false);
		}
		return pnTablero;
	}

	private void aniadirBotones() {
		int numeroBotones = spaceInvaders.getDimension();
		for(int i=0;i<numeroBotones;i++) {
			getPnTablero().add(nuevoBoton(i));
			validate();
		}
	}
	private void habilitaTablero(boolean habilita) {
		for (int i = 0; i < getPnTablero().getComponents().length; i++) {
			getPnTablero().getComponents()[i].setEnabled(habilita);
		}
	}

	private void dispara(int i) {
		spaceInvaders.dipara(i);
		representaspaceInvaders(i);
	}

	private void representaspaceInvaders(int i) {
		pintaPuntos();
		despintaDisparo();
		pintaCasilla(i);
		deshabilitaBoton(i);
		compruebaFin();

	}

	private void compruebaFin() {
		if (spaceInvaders.isFinJuego()) {
			descubreTablero();
			habilitaTablero(false);
			JOptionPane.showMessageDialog(this, spaceInvaders.getMotivoFin(), "Invasi�n espacial",
					JOptionPane.INFORMATION_MESSAGE);
		}
	}

	private void descubreTablero() {
		for (int i = 0; i < getPnTablero().getComponentCount(); i++) {
			pintaCasilla(i);
		}
	}

	private void deshabilitaBoton(int i) {
		((JButton) getPnTablero().getComponent(i)).setEnabled(false);

	}

	private void pintaCasilla(int i) {
		ImageIcon imagen = new ImageIcon(VentanaPrincipal.class.getResource(spaceInvaders.obtenerImagen(i)));
		((JButton) getPnTablero().getComponent(i)).setIcon(imagen);
		((JButton) getPnTablero().getComponent(i)).setDisabledIcon(imagen);
	}

	private void despintaDisparo() {
		getPnDisparos().remove(0);
		getPnDisparos().repaint(); // Obliga a repintarse al panel cuando se elimina un componente
	}

	private void pintaPuntos() {
		getTxPuntos().setText(String.valueOf(spaceInvaders.getPuntuacion()));

	}

	private JLabel getLblPlaneta() {
		if (lblPlaneta == null) {
			lblPlaneta = new JLabel("");
			lblPlaneta.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/earth.jpg")));
			lblPlaneta.setBounds(854, 27, 200, 175);
		}
		return lblPlaneta;
	}

	private JLabel getLblScore() {
		if (lblScore == null) {
			lblScore = new JLabel("Score");
			lblScore.setFont(new Font("Tahoma", Font.BOLD, 18));
			lblScore.setForeground(Color.WHITE);
			lblScore.setBounds(686, 27, 60, 29);
		}
		return lblScore;
	}

	private JTextField getTxPuntos() {
		if (TxPuntos == null) {
			TxPuntos = new JTextField();
			TxPuntos.setFocusable(false);
			TxPuntos.setHorizontalAlignment(SwingConstants.CENTER);
			TxPuntos.setFont(new Font("Tahoma", Font.BOLD, 16));
			TxPuntos.setText(String.valueOf(spaceInvaders.getPuntuacion()));
			TxPuntos.setForeground(Color.GREEN);
			TxPuntos.setBackground(Color.BLACK);
			TxPuntos.setBounds(672, 47, 86, 34);
			TxPuntos.setColumns(10);
		}
		return TxPuntos;
	}

	private JLabel getLblNave() {
		if (lblNave == null) {
			lblNave = new JLabel("");
			lblNave.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/spaceship.png")));
			lblNave.setBounds(428, 47, 126, 66);
		}
		return lblNave;
	}

	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnJuego());
			menuBar.add(getMnNiveles());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}

	private JMenu getMnJuego() {
		if (mnJuego == null) {
			mnJuego = new JMenu("Juego");
			mnJuego.setMnemonic('J');
			mnJuego.add(getMntmNuevo());
			mnJuego.add(getMntmSalir());
		}
		return mnJuego;
	}

	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setMnemonic('d');
			mnAyuda.add(getMntmAcercaDe());
		}
		return mnAyuda;
	}

	private JMenuItem getMntmNuevo() {
		if (mntmNuevo == null) {
			mntmNuevo = new JMenuItem("Nuevo");
			mntmNuevo.setMnemonic('n');
			mntmNuevo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					inicializar(SpaceInvaders.DEFAULT_DIFFICULTY);
				}
			});
			mntmNuevo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
		}
		return mntmNuevo;
	}

	private void inicializar(Nivel nivel) {
		spaceInvaders.inicializar(nivel);
		inicializarInterfaz(nivel);
	}

	private void inicializarInterfaz(Nivel nivel) {
		getBtnDado().setEnabled(true);
		eliminaDisparos();
		pintaPuntos();
		despintaTablero();
	}

	private void despintaTablero() {
		for (int i = 0; i < getPnTablero().getComponentCount(); i++) {
			((JButton) getPnTablero().getComponents()[i]).setIcon(null);
			((JButton) getPnTablero().getComponents()[i]).setDisabledIcon(null);
		}
	}

	private void eliminaDisparos() {
		getPnDisparos().removeAll();
		getPnDisparos().repaint();
	}

	private JMenuItem getMntmSalir() {
		if (mntmSalir == null) {
			mntmSalir = new JMenuItem("Salir");
			mntmSalir.setMnemonic('s');
			mntmSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					confirmarSalir();
				}
			});
		}
		return mntmSalir;
	}

	private void confirmarSalir() {
		if (JOptionPane.showConfirmDialog(this,
				"�Estas seguroque quieres salir de la aplicacion?") == JOptionPane.YES_OPTION) {

			System.exit(0);
		}

	}
	
	private JButton nuevoBoton(int i) {
		JButton bt = new JButton("");
		bt.setActionCommand(String.valueOf(i));
		bt.setBackground(Color.BLACK);
		bt.setToolTipText("Click para disparar");
		bt.addActionListener(pbt);
		return bt;
	}

	private JMenuItem getMntmAcercaDe() {
		if (mntmAcercaDe == null) {
			mntmAcercaDe = new JMenuItem("Acerca de");
			mntmAcercaDe.setMnemonic('a');
			mntmAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null,
							"Aplicaci�n realizada por David Feito Campo \n Pr�cticas CPM 25-26 \n EII Oviedo",
							"Acerca de", JOptionPane.INFORMATION_MESSAGE);
				}
			});
		}
		return mntmAcercaDe;
	}
	private JMenu getMnNiveles() {
		if (mnNiveles == null) {
			mnNiveles = new JMenu("Niveles");
			mnNiveles.setMnemonic('n');
			mnNiveles.add(getRbmFacil());
			mnNiveles.add(getRbmIntermedio());
			mnNiveles.add(getRbmDificil());
		}
		return mnNiveles;
	}
	private JRadioButtonMenuItem getRbmFacil() {
		if (rbmFacil == null) {
			rbmFacil = new JRadioButtonMenuItem("Mariposa");
			rbmFacil.addActionListener(pbn);
			rbmFacil.setMnemonic('m');
			buttonGroup.add(rbmFacil);
		}
		return rbmFacil;
	}
	private JRadioButtonMenuItem getRbmIntermedio() {
		if (rbmIntermedio == null) {
			rbmIntermedio = new JRadioButtonMenuItem("Ni frio ni calor");
			rbmIntermedio.addActionListener(pbn);
			rbmIntermedio.setSelected(true);
			rbmIntermedio.setMnemonic('i');
			buttonGroup.add(rbmIntermedio);
		}
		return rbmIntermedio;
	}
	private JRadioButtonMenuItem getRbmDificil() {
		if (rbmDificil == null) {
			rbmDificil = new JRadioButtonMenuItem("Chunguisimo");
			rbmDificil.addActionListener(pbn);
			rbmDificil.setMnemonic('c');
			buttonGroup.add(rbmDificil);
		}
		return rbmDificil;
	}
	
	private void redimensionarTablero(Nivel nivel) {
		int ancho = 0;
		int x = 0;
		switch (nivel) {
		case FACIL: {
			x = 20;
			ancho = 1010;
			break;
			}
		case INTERMEDIO: {
			x = 120;
			ancho = 815;
			break;
			}
		case DIFICIL: {
			x = 190;
			ancho = 610;
			break;
			}
		}
		getPnTablero().setBounds(x, 210, ancho, 105);
		getPnTablero().setLayout(new GridLayout(1, spaceInvaders.getDimension(), 4, 0)); //filas, columnas, hgap, vgap
		getPnTablero().removeAll();
		// Se a�aden los botones al tablero
		aniadirBotones();	
	}
	
}
