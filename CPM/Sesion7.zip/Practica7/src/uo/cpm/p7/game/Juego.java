package uo.cpm.p7.game;

import uo.cpm.p7.model.*;
import uo.cpm.p7.model.Casilla.TipoCasilla;

public class Juego {
	
	public static final int MAX_DISPAROS = 4;
	private int puntos;
	private int disparos;
	private Tablero tablero; 
	private Casilla casillaDisparada;
	private boolean finJuego;
	private Nivel nivel;
	
	
	public Juego(){
		inicializarJuego(Nivel.INTERMEDIO);
	}

	public void inicializarJuego(Nivel nivel){

		setNivel(nivel);
		tablero = new Tablero(nivel);
		puntos = 1000;
		disparos = 0;
		casillaDisparada=null;
		finJuego = false;
		}
	
	private void setNivel(Nivel nivel) {
		this.nivel=nivel;
	}
	public Nivel getNivel() {
		return this.nivel;
	}
	
	public Tablero getTablero() {
		return tablero;
	}
	
	public Casilla getCasillaDisparada() {
		return casillaDisparada;
	}

	public void setCasillaDisparada(Casilla casillaDisparada) {
		this.casillaDisparada = casillaDisparada;
	}
	
	public boolean isFinJuego() {
		return finJuego;
	}
	
	public void dispara(int i){
		disparos --;
		setCasillaDisparada(tablero.getCasillas()[i]); // guardamos la casilla sobre la que se ha disparado		
		if (tablero.getCasillas()[i].getTipoCasilla().equals(TipoCasilla.METEORITO)) {
			puntos = 0;
			finJuego = true;
		}else {
			puntos += tablero.getCasillas()[i].getPuntos();
			finJuego = isPartidaFinalizada();
		}
		
	}
	
	public boolean isPartidaFinalizada() { 
		return (getCasillaDisparada().getTipoCasilla().equals(TipoCasilla.ENEMIGO) || disparos == 0) ;
	}

	public int getPuntos() {
		return puntos;
	}

	public void lanzar() {
		setDisparos(Dado.lanzar());	
	}
	
	public int getDisparos() {
		return disparos;
	}

	private void setDisparos(int disparos) {
		this.disparos = disparos;
	}
	
	public String obtenerImagen(int i) {
		return getTablero().obtenerImagen(i);
	}
	
}
